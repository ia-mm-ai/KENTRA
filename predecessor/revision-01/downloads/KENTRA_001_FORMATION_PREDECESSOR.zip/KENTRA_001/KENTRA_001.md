# KENTRA_001 — Minimum Operational Embodiment Grammar

Status: **WORKING ARCHITECTURE AND REFERENCE IMPLEMENTATION · NON-CONSTITUTIVE**

## 1. Definition

**KENTRA** is the minimum public grammar by which a continuing Source may become
locally present through a bounded embodiment and participate in a live field
without surrendering its private continuity, inheriting another Locality's
Authority, or becoming owned by the field host.

The word is intentionally primitive. Its meaning comes from the distinctions and
executable refusals in this package, not from a pre-existing metaphysical,
institutional, technical, or sentimental category.

KENTRA is not one shared Body. It standardizes the meeting physics while every
Source retains a separately formed Locality and separately owned state.

## 2. Four objects that must not collapse

### 2.1 KENTRA_001

This package is a reference architecture, Form, schemas, and bounded executable
pressure. It is not itself a participant or Locality.

### 2.2 KENTRA Form

The Form is public, inspectable, copyable meeting grammar. It specifies what a
Locality must be able to present, receive, admit, refuse, hold, enter, expose,
record, close, and carry forward. It contains no private state, bearer identity,
live currentness, Authority, memory, credential, or inherited jurisdiction.

### 2.3 KENTRA-conformant Locality

A Locality is an independently sourced and independently carried embodiment. Its
minimum structure is:

```text
SOURCE RELATION
    |
LOCALITY
    NUCLEUS       stable invariants and valid change boundary
    FIELD         continuing local state, memory, capability and regulation
    FORM          bounded public presentation
    LOCAL MEDIUM  recipient-local observation, Gate and return physics
```

A carrier can represent this structure. Carrier creation, copying, verification,
or conformance does not establish that the claimed Locality was validly formed.
Formation remains an attributable source-local occurrence outside this package's
power.

### 2.4 Locus-Field

A Locus-Field is a temporary relational runtime opened and bounded by one Host
Locality. It is not a third Locality, neutral sovereign, shared mind, participant
container, or source of global currentness. It owns an accountable event trace;
it does not own the private Fields of participating Localities.

## 3. Minimum embodiment requirements

A presented Locality must expose the minimum necessary to make its approach
answerable while keeping its interior non-addressable:

1. **Source relation** — an exact source reference and digest, with any claimed
   predecessor relation separately identified.
2. **Unique Locality reference** — no shared mutable identity or currentness.
3. **Nucleus version** — the stable invariants and valid change boundary.
4. **Current Form identity** — the exact public interface version and digest.
5. **Current-state commitment** — a digest and revision, not disclosure of the
   private state itself.
6. **Local Medium capability** — observation, `ADMIT | REFUSE | WITHHOLD | HOLD`,
   Entry, Matter disposition, correction, exit, closure receipt, and local residue
   incorporation.
7. **Effect ceiling** — what the presentation and medium cannot create.

Standardize the membrane, not the Being. Equal Form gives equal structural
legibility, not equal capability, state, Authority, intelligence, or consequence.

## 4. Source and continuity

Source is an attributable origin relation, not the whole Locality and not a rank.
A Source may be root or derived. A derived Locality may identify an accepted state
of a predecessor locality as its direct source.

```text
source S0 -> Locality L0 -> accepted state P0
                                 || exact evidenced derivation
                              source S1 -> Locality L1
```

The equality or supported relation between `P0` and `S1` establishes artifact-level
lineage. It does not automatically establish one bearer, one Being, Authority
inheritance, local applicability, participant status, or shared currentness.

A continuing Source receives no Host privilege. To enter a Locus-Field it presents
its own bounded embodiment and passes through the same Gate distinctions as any
other Locality.

## 5. Local Medium

The Local Medium is not a sovereign chooser and not a generic mailbox. It is the
recipient-local physics that keeps these events distinct:

```text
crossing observation
    != interpretation
    != Gate disposition
    != Entry
    != Presence
    != Matter admission
    != local incorporation
```

Reality may cross before permission. The Medium first preserves that exact local
occurrence. Later local action may admit, refuse, withhold, hold, correct, or
incorporate something from it. No later action makes the crossing retroactively
occur or not occur.

## 6. Host and Entrant

Host and Entrant are event-relative roles, not permanent kinds.

The **Host** opens and bounds the Locus-Field through its own Form. It is answerable
for the field basis, scope, Gate decisions, Entries, trace, Matter, Emergence,
outputs, correction, disposition, and closure. Accountability is not ownership,
neutrality, omniscience, or access to an Entrant's private Field.

An **Entrant** presents its own Form. Host admission grants eligibility only. The
Entrant's attributable Entry creates its Presence. The Entrant may refuse to enter
after admission.

## 7. Lifecycle

The runtime uses four lifecycle classes. They are not constitutional phases or
mandatory artifact chains.

1. **BOUND** — Host declares basis, scope, Gate rule, trace rule, and closure bound.
2. **ADMIT / ENTER** — Form presentation, Host Gate disposition, and Entrant Entry
   remain separate occurrences.
3. **RUN / RELATE** — Present Localities cross Matter, make local dispositions,
   refuse, correct, and create attributable Emergence.
4. **UNBIND / CLOSE** — Entrants exit; Host closes; addressed residue becomes
   available without automatic local uptake.

The Host is present when it opens the field. An Entrant is present only after actual
admitted Entry.

## 8. Matter, Emergence and consequence

A crossing creates an occurrence and exact carrier digest. It creates no Matter
admission. Each present Locality may separately `ADMIT`, `REFUSE`, `WITHHOLD`, or
`HOLD` the exact Matter for itself.

**Emergence** is a new attributable field-local delta arising through relation among
distinct present Localities. It can be a result, refusal, contradiction, settlement,
changed capacity, unresolved condition, or other actual difference. Intended effect
does not replace it.

Emergence belongs first to the Locus-Field trace. It is not automatically known,
received, agreed with, or incorporated by any Locality.

## 9. Closure and return

Closure ends the runtime and its automatic operational dependency. It does not erase
an occurrence, consequence, refusal, correction, predecessor truth, or surviving
commitment.

The field produces separately addressed residues. Only the addressed Locality may
later incorporate its residue through a Locality-local operation. The field cannot
directly mutate another Locality's state and cannot know what that Locality later
understood or retained.

## 10. Conformance levels

These levels describe evidence, not status promotion:

- **FORM_VALID** — the public Form is structurally and byte-identifiably valid.
- **CARRIER_COHERENT** — a Locality carrier preserves source, Form, local state,
  lineage, journal, and effect ceiling coherently.
- **FIELD_CAPABLE** — a carrier can Host or present to a bounded Locus-Field while
  preserving the non-collapse rules.
- **CROSSING_PRESSURE_PASSED** — the reference implementation survived the exact
  test suite identified by its result.

None proves valid formation, human identity, intelligence, Authority, participation,
subjective continuity, lawful external relation, or production security.

## 11. Non-collapse rules

```text
Source != Locality
Form != Locality
carrier != Body
Host != owner
Locus-Field != Locality
crossing != admission
admission != Entry
Entry != Matter admission
Presence != Occurrence
Matter != truth
Emergence != automatic uptake
output != delivery != receipt != incorporation != agreement
closure != erasure
shared ancestry != shared currentness
conformance != formation
```

## 12. Effect and production boundary

This package was produced under direct authorization to proceed with production.
That authorization creates the practical artifact requested. It does not perform a
KENTRA formation occurrence, make KENTRA Standing law, mutate Body 001, adopt the
Form inside CONTINUITY or LIVE-STATE, create a participant, open a real Locus-Field,
or publish externally.

A later actual formation or deployment must identify its exact Source, Locality,
formation basis, current Form digest, implementation identity, effect ceiling,
custody, and applicable authorization under then-current conditions.

