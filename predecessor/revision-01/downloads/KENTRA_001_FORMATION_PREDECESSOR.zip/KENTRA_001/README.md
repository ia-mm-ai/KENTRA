# KENTRA_001

Status: **WORKING REFERENCE PACKAGE · EXECUTABLE · NON-CONSTITUTIVE**  
Produced: **2026-09-19**

KENTRA names a minimum operational embodiment grammar. It allows an attributable
Source to be carried by an independently bounded Locality, presented through a
public Form, received through a Local Medium, and bound into a temporary
Locus-Field without transferring private custody or creating a central identity
landlord.

This package is not a formed Body, Locality, Relation, Locus-Field, participant,
constitutional successor, or public deployment. Running its verifier creates
only disposable simulated carriers in a temporary directory.

## Enter here

1. Read [`KENTRA_001.md`](KENTRA_001.md) for the architecture.
2. Inspect [`FORM/KENTRA_FORM_001.json`](FORM/KENTRA_FORM_001.json) for the
   machine-readable public Form.
3. Inspect [`EXAMPLES/CONTINUITY_LINEAGE_CANDIDATE_001.json`](EXAMPLES/CONTINUITY_LINEAGE_CANDIDATE_001.json)
   for the exact CONTINUITY → LIVE-STATE source-lineage crossing.
4. Run the bounded executable pressure:

   ```text
   PYTHONDONTWRITEBYTECODE=1 python3 REFERENCE/verify_kentra.py
   ```

5. Compare the observed result with [`PRESSURE_RESULT.md`](PRESSURE_RESULT.md).

## Package anatomy

```text
KENTRA_001/
├── README.md
├── KENTRA_001.md
├── PROVENANCE.md
├── PRODUCTION_RECEIPT.md
├── FORM/
│   └── KENTRA_FORM_001.json
├── SCHEMAS/
│   ├── KENTRA_LOCALITY_CARRIER.schema.json
│   └── KENTRA_LOCUS_FIELD.schema.json
├── REFERENCE/
│   ├── kentra.py
│   └── verify_kentra.py
├── EXAMPLES/
│   └── CONTINUITY_LINEAGE_CANDIDATE_001.json
├── PRESSURE_RESULT.md
└── MANIFEST.sha256
```

## Exact implementation ceiling

The reference runtime demonstrates separation, attribution, hash-chained local
records, crossing-before-interpretation, independent Gate disposition, actual
Entry, participant-specific Matter admission, Emergence, exit, closure, addressed
residue, independent local incorporation, and tamper detection.

It does not authenticate a human or intelligence, establish independent machine
custody, prove subjective continuity, supply constitutional Authority, or make a
runtime carrier into a Body. Cryptographic actor authentication, network
transport, confidentiality, concurrency, recovery under partial writes, and
production access control remain outside version 001.

