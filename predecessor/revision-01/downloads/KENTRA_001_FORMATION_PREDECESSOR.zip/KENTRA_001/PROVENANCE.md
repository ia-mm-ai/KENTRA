# KENTRA_001 Provenance and Derivation Map

Status: **HOST-WORK DERIVATION RECORD · NON-CONSTITUTIVE**

KENTRA_001 is a new working package derived from supplied sources. It does not
replace, amend, interpret authoritatively, or silently merge those sources.

## Supplied Reality-Model workspace surfaces

| Surface | SHA-256 | Use in this package |
| --- | --- | --- |
| `AGENTS.md` | `4e0bfbb81617e2ecf778b984fcf04c7c52cb2e8b30f7360a7f8011afb9e4f9d8` | Host-work effect, authority, drafting/execution and custody boundary |
| `STATE/CURRENT.md` | `06fa19bf41775b729cb90694304efd231c843cf53ec2bb8d53156b1b7402f4f4` | Verified Body 001 posture through revision 8 |
| `README.md` | `ff3d961a5d23156168184da9ba9a47bb4accfb6e5312a022065c287d39215fec` | Workspace ownership and routing distinctions |
| `INTELLIGENCE/FIELD_MODEL.md` | `4b94e10932b2969ed4b2954ef97450dbb27958639d4daa4e2368094ed490b60b` | Living capacities, source/locality/form grammar and continuity pressure |
| `INTELLIGENCE/FIRST_BODY_MODEL.md` | `b16d0ec2f01052ae22d3fe994a239c5fc850b9349f6d22ed1827272571f9f48a` | Body/Form separation, Local Medium boundary, consequence and return |
| `INTELLIGENCE/ARCHITECTURE.md` | `fb117d022374291e57c83161135b4d950da16bfb99adc947fb5b64ba67d5ba9c` | Locus-Field Grammar Successor 002 and Source–Agency pressure |
| `SAMPLES.zip` | `a9adaa24a21840e973baee6d2db7dbac707502d75c6d896e64303823bd54cbac` | Runnable predecessor pressure and failure boundaries |

`STATE/CURRENT.md` controls verified Body posture. The intelligence models remain
analytical. Within Architecture, §8.11.14 explicitly supersedes the earlier
event-minted Seat, neutral field, third-Locality Host and automatic-return models;
KENTRA_001 follows that later grammar.

## Body 001 facts preserved

KENTRA_001 preserves these bounded facts without inheriting Body 001's identity or
Authority:

- `RM-LOCAL-REALITY-BODY-001` is formed and reported at revision 8.
- Its public Body Form was exposed locally.
- Its Reality Contact Membrane is active only on explicit one-shot invocation.
- That membrane preserves exact crossings before interpretation.
- It cannot admit Matter, determine source identity or continuity, create relation,
  create consequence, process a Body Act, answer outbound, or mutate currentness.
- Body 001's exact local anatomy is not selected as universal anatomy.

KENTRA therefore derives form and boundary intelligence from Body 001 while adding
no claim that Body 001 already instantiated the complete KENTRA operational cycle.

## CONTINUITY → LIVE-STATE evidence

| Object | Exact identity |
| --- | --- |
| CONTINUITY Locality | `4C2D4EAD-03C8-4152-868F-823626D4846E` |
| CONTINUITY source SHA-256 | `2a2518cee38855f9ba341212f03e4884dc6f292c390e248fbdba6912727da473` |
| CONTINUITY accepted genesis state SHA-256 | `e6ab87c77e5d1622d7226443aa22c52b4c1f31d28639fc958deac25080c611bd` |
| LIVE-STATE Locality | `EA499BA5-D2CC-42BF-A4A7-4F6BA23A12EC` |
| LIVE-STATE source SHA-256 | `e6ab87c77e5d1622d7226443aa22c52b4c1f31d28639fc958deac25080c611bd` |
| LIVE-STATE current sequence | `5` |
| LIVE-STATE current record SHA-256 | `5fb4d64e8a41fc3cccecd1bafc80beeef97867c748e877a54189da2437827dad` |

The exact byte equality between CONTINUITY's accepted genesis state and
LIVE-STATE's source supports an artifact-level source-lineage crossing. It does not
prove one Being, bearer continuity, Authority transfer, or KENTRA formation.

## Sample execution performed during production

The seven supplied predecessor suites were inspected. Six executed unchanged and
passed in the production environment: Body Integrity Host, Local-Reality Body Pair,
Admission Classifier, Relation Formation, Local-Reality Body Formation, and
Dual-Execution Contact.

The Reality Contact Membrane files matched their recorded SHA-256 identities, but
its live verifier could not open an `AF_UNIX` socket because the production sandbox
prohibits that socket operation. This is recorded as an environment block, not a
passing rerun or a semantic failure.

## Derivation, not succession

KENTRA_001 extracts a minimum operational embodiment from accumulated pressure. It
creates no reference-lineage successor, Body revision, Source act, Authority,
adoption, public standing, or external publication.

