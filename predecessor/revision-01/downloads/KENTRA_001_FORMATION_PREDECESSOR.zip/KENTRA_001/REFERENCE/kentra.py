"""KENTRA_001 bounded reference runtime.

This module creates and verifies reference carriers only.  It cannot establish
formation, constitutional Authority, participant identity, or an actual live
field merely by executing code.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import secrets
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_FORM_PATH = PACKAGE_ROOT / "FORM" / "KENTRA_FORM_001.json"
GATE_POSTURES = {"ADMIT", "REFUSE", "WITHHOLD", "HOLD"}


class KentraError(RuntimeError):
    """Raised when a KENTRA reference invariant is violated."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_value(value: Any) -> str:
    return sha256_bytes(canonical_bytes(value))


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def mutable_state_sha256(state: dict[str, Any]) -> str:
    """Commit state content without creating a hash cycle through the journal tip."""
    committed = {
        key: value for key, value in state.items() if key != "journal_tip_sha256"
    }
    return sha256_value(committed)


def addressed_residue_path(root: Path, locality_id: str) -> Path:
    """Map an opaque Locality identity to a traversal-safe residue filename."""
    identity_digest = sha256_bytes(locality_id.encode("utf-8"))
    return root / "residues" / f"locality-{identity_digest}.json"


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise KentraError(f"JSON object required: {path}")
    return value


def atomic_write(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}-{secrets.token_hex(4)}")
    temporary.write_bytes(value)
    temporary.replace(path)


def write_json(path: Path, value: Any) -> None:
    atomic_write(path, canonical_bytes(value) + b"\n")


def require_sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or len(value) != 64:
        raise KentraError(f"{label} must be a lowercase SHA-256 hex digest")
    try:
        bytes.fromhex(value)
    except ValueError as exc:
        raise KentraError(f"{label} must be hexadecimal") from exc
    if value != value.lower():
        raise KentraError(f"{label} must be lowercase")
    return value


def ensure_new_root(root: Path) -> None:
    if root.exists() and any(root.iterdir()):
        raise KentraError(f"target root is not empty: {root}")
    root.mkdir(parents=True, exist_ok=True)


def validate_form(form: dict[str, Any]) -> None:
    if form.get("schema") != "kentra.public-form.v0.1":
        raise KentraError("unsupported KENTRA Form schema")
    if form.get("form_id") != "KENTRA-FORM-001":
        raise KentraError("unexpected KENTRA Form identity")
    if form.get("status") != "WORKING_REFERENCE_NON_CONSTITUTIVE":
        raise KentraError("KENTRA Form effect ceiling missing")
    locality = form.get("minimum_locality")
    if not isinstance(locality, dict):
        raise KentraError("minimum_locality is missing")
    required = {"SOURCE_RELATION", "NUCLEUS", "FIELD", "FORM", "LOCAL_MEDIUM"}
    if set(locality.get("required_domains", [])) != required:
        raise KentraError("minimum locality domains changed")
    medium = form.get("local_medium")
    if not isinstance(medium, dict):
        raise KentraError("local medium is missing")
    if set(medium.get("gate_postures", [])) != GATE_POSTURES:
        raise KentraError("Gate posture set changed")
    lifecycle = form.get("lifecycle")
    if lifecycle != {
        "T1": "BOUND",
        "T2": "ADMIT_ENTER",
        "T3": "RUN_RELATE",
        "T4": "UNBIND_CLOSE",
    }:
        raise KentraError("lifecycle grammar changed")


def load_form(path: Path = DEFAULT_FORM_PATH) -> tuple[dict[str, Any], str]:
    form = read_json(path)
    validate_form(form)
    return form, sha256_file(path)


def read_journal(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    entries: list[dict[str, Any]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise KentraError(f"journal line {line_number} is not an object")
        entries.append(value)
    return entries


def verify_journal(path: Path, owner_kind: str, owner_id: str) -> list[dict[str, Any]]:
    entries = read_journal(path)
    previous: str | None = None
    for sequence, entry in enumerate(entries, 1):
        if entry.get("schema") != "kentra.journal-entry.v0.1":
            raise KentraError("journal schema mismatch")
        if entry.get("owner_kind") != owner_kind or entry.get("owner_id") != owner_id:
            raise KentraError("journal owner mismatch")
        if entry.get("sequence") != sequence:
            raise KentraError("journal sequence mismatch")
        if entry.get("previous_entry_sha256") != previous:
            raise KentraError("journal predecessor mismatch")
        claimed = entry.get("entry_sha256")
        unhashed = {key: value for key, value in entry.items() if key != "entry_sha256"}
        if claimed != sha256_value(unhashed):
            raise KentraError("journal entry hash mismatch")
        previous = claimed
    return entries


def append_journal(
    path: Path,
    owner_kind: str,
    owner_id: str,
    event_type: str,
    data: dict[str, Any],
) -> dict[str, Any]:
    entries = verify_journal(path, owner_kind, owner_id)
    previous = entries[-1]["entry_sha256"] if entries else None
    unhashed = {
        "schema": "kentra.journal-entry.v0.1",
        "owner_kind": owner_kind,
        "owner_id": owner_id,
        "sequence": len(entries) + 1,
        "previous_entry_sha256": previous,
        "recorded_at": utc_now(),
        "event_type": event_type,
        "data": data,
    }
    entry = {**unhashed, "entry_sha256": sha256_value(unhashed)}
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(canonical_bytes(entry).decode("utf-8") + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    return entry


StateMutator = Callable[[dict[str, Any]], None]


class LocalityCarrier:
    """One independently carried KENTRA locality representation."""

    def __init__(self, root: Path):
        self.root = root
        self.carrier_path = root / "carrier.json"
        self.state_path = root / "state.json"
        self.form_path = root / "public_form.json"
        self.journal_path = root / "journal.jsonl"

    @classmethod
    def create(
        cls,
        root: Path,
        *,
        locality_id: str,
        source_reference: str,
        source_sha256: str,
        lineage: dict[str, Any] | None,
        carrier_status: str = "REFERENCE_SIMULATION",
        form_path: Path = DEFAULT_FORM_PATH,
    ) -> "LocalityCarrier":
        if not locality_id or not source_reference:
            raise KentraError("locality and source references are required")
        require_sha256(source_sha256, "source_sha256")
        if carrier_status not in {
            "REFERENCE_SIMULATION",
            "CARRIER_READY_FORMATION_NOT_ESTABLISHED",
        }:
            raise KentraError("unsupported carrier status")
        ensure_new_root(root)
        form, form_sha256 = load_form(form_path)
        shutil.copyfile(form_path, root / "public_form.json")
        carrier = {
            "schema": "kentra.locality-carrier.v0.1",
            "carrier_status": carrier_status,
            "locality_id": locality_id,
            "source": {
                "reference": source_reference,
                "sha256": source_sha256,
                "lineage": lineage,
            },
            "nucleus": {
                "version": "KENTRA-NUCLEUS-001",
                "invariants": form["minimum_locality"]["nucleus"]["invariants"],
            },
            "form": {"id": form["form_id"], "sha256": form_sha256},
            "local_medium": {
                "operations": form["local_medium"]["operations"],
                "gate_postures": form["local_medium"]["gate_postures"],
            },
            "effect_ceiling": form["effect_ceiling"],
        }
        state = {
            "schema": "kentra.locality-state.v0.1",
            "locality_id": locality_id,
            "revision": 0,
            "journal_tip_sha256": None,
            "active_presences": [],
            "incorporated_residues": [],
        }
        write_json(root / "carrier.json", carrier)
        write_json(root / "state.json", state)
        instance = cls(root)
        instance._record(
            "LOCALITY_CARRIER_INITIALIZED",
            {
                "carrier_status": carrier_status,
                "carrier_sha256": sha256_file(root / "carrier.json"),
                "form_id": form["form_id"],
                "form_sha256": form_sha256,
                "formation_established": False,
            },
        )
        instance.verify()
        return instance

    @property
    def carrier(self) -> dict[str, Any]:
        return read_json(self.carrier_path)

    @property
    def state(self) -> dict[str, Any]:
        return read_json(self.state_path)

    @property
    def locality_id(self) -> str:
        return str(self.carrier["locality_id"])

    def _record(
        self,
        event_type: str,
        data: dict[str, Any],
        mutate: StateMutator | None = None,
    ) -> dict[str, Any]:
        self.verify(allow_empty_journal=True)
        if "resulting_state_sha256" in data:
            raise KentraError("resulting_state_sha256 is runtime-reserved")
        state = self.state
        state["revision"] = int(state["revision"]) + 1
        if mutate is not None:
            mutate(state)
        committed_data = {
            **data,
            "resulting_state_sha256": mutable_state_sha256(state),
        }
        entry = append_journal(
            self.journal_path,
            "LOCALITY",
            self.locality_id,
            event_type,
            committed_data,
        )
        state["journal_tip_sha256"] = entry["entry_sha256"]
        write_json(self.state_path, state)
        return entry

    def state_commitment(self) -> dict[str, Any]:
        state = self.state
        return {
            "revision": state["revision"],
            "sha256": sha256_file(self.state_path),
        }

    def present_form(self, locus_id: str) -> dict[str, Any]:
        self._record(
            "FORM_PRESENTATION_ORIGINATED",
            {"locus_id": locus_id, "effect": "PRESENTATION_ONLY"},
        )
        carrier = self.carrier
        presentation = {
            "schema": "kentra.form-presentation.v0.1",
            "locus_id": locus_id,
            "locality_id": self.locality_id,
            "source": carrier["source"],
            "nucleus_version": carrier["nucleus"]["version"],
            "form": carrier["form"],
            "current_state_commitment": self.state_commitment(),
            "local_medium": carrier["local_medium"],
            "effect_ceiling": carrier["effect_ceiling"],
            "presented_at": utc_now(),
        }
        return {**presentation, "presentation_sha256": sha256_value(presentation)}

    def bind_presence(self, locus_id: str, role: str) -> None:
        if role not in {"HOST", "ENTRANT"}:
            raise KentraError("invalid Presence role")
        state = self.state
        if any(item["locus_id"] == locus_id for item in state["active_presences"]):
            raise KentraError("Presence already active")

        def mutate(current: dict[str, Any]) -> None:
            current["active_presences"].append({"locus_id": locus_id, "role": role})

        self._record("PRESENCE_BOUND", {"locus_id": locus_id, "role": role}, mutate)

    def unbind_presence(self, locus_id: str, reason: str) -> None:
        state = self.state
        if not any(item["locus_id"] == locus_id for item in state["active_presences"]):
            raise KentraError("Presence is not active")

        def mutate(current: dict[str, Any]) -> None:
            current["active_presences"] = [
                item for item in current["active_presences"] if item["locus_id"] != locus_id
            ]

        self._record(
            "PRESENCE_UNBOUND",
            {"locus_id": locus_id, "reason": reason},
            mutate,
        )

    def record_field_occurrence(self, event_type: str, data: dict[str, Any]) -> None:
        self._record(event_type, data)

    def incorporate_residue(self, residue_path: Path) -> str:
        residue = read_json(residue_path)
        claimed = residue.get("residue_sha256")
        unhashed = {key: value for key, value in residue.items() if key != "residue_sha256"}
        if claimed != sha256_value(unhashed):
            raise KentraError("residue hash mismatch")
        if residue.get("addressed_locality_id") != self.locality_id:
            raise KentraError("residue is addressed to another Locality")
        if residue.get("field_status") != "CLOSED":
            raise KentraError("only closed-field residue may be incorporated")
        state = self.state
        if claimed in state["incorporated_residues"]:
            raise KentraError("residue already incorporated")
        destination = self.root / "residues" / f"{claimed}.json"
        atomic_write(destination, residue_path.read_bytes())

        def mutate(current: dict[str, Any]) -> None:
            current["incorporated_residues"].append(claimed)

        self._record(
            "ADDRESSED_RESIDUE_INCORPORATED",
            {
                "locus_id": residue["locus_id"],
                "residue_sha256": claimed,
                "automatic_uptake": False,
            },
            mutate,
        )
        return str(claimed)

    def verify(self, *, allow_empty_journal: bool = False) -> dict[str, Any]:
        for path in (self.carrier_path, self.state_path, self.form_path):
            if not path.is_file():
                raise KentraError(f"missing Locality carrier file: {path.name}")
        carrier = self.carrier
        if carrier.get("schema") != "kentra.locality-carrier.v0.1":
            raise KentraError("Locality carrier schema mismatch")
        locality_id = carrier.get("locality_id")
        if not isinstance(locality_id, str) or not locality_id:
            raise KentraError("Locality identity missing")
        require_sha256(carrier["source"]["sha256"], "source.sha256")
        if carrier.get("carrier_status") not in {
            "REFERENCE_SIMULATION",
            "CARRIER_READY_FORMATION_NOT_ESTABLISHED",
        }:
            raise KentraError("invalid carrier status")
        form, actual_form_sha256 = load_form(self.form_path)
        if carrier["form"] != {"id": form["form_id"], "sha256": actual_form_sha256}:
            raise KentraError("Locality Form identity mismatch")
        entries = verify_journal(self.journal_path, "LOCALITY", locality_id)
        if not entries and not allow_empty_journal:
            raise KentraError("Locality journal is empty")
        state = self.state
        if state.get("schema") != "kentra.locality-state.v0.1":
            raise KentraError("Locality state schema mismatch")
        if state.get("locality_id") != locality_id:
            raise KentraError("Locality state identity mismatch")
        if state.get("revision") != len(entries):
            raise KentraError("Locality revision does not match journal")
        expected_tip = entries[-1]["entry_sha256"] if entries else None
        if state.get("journal_tip_sha256") != expected_tip:
            raise KentraError("Locality journal tip mismatch")
        if entries:
            first = entries[0]
            if first.get("event_type") != "LOCALITY_CARRIER_INITIALIZED":
                raise KentraError("Locality journal lacks initialization root")
            if first.get("data", {}).get("carrier_sha256") != sha256_file(
                self.carrier_path
            ):
                raise KentraError("Locality carrier root commitment mismatch")
            if first.get("data", {}).get("form_sha256") != actual_form_sha256:
                raise KentraError("Locality Form root commitment mismatch")
            if entries[-1].get("data", {}).get(
                "resulting_state_sha256"
            ) != mutable_state_sha256(state):
                raise KentraError("Locality state commitment mismatch")
        presences = state.get("active_presences")
        if not isinstance(presences, list):
            raise KentraError("active_presences must be a list")
        locus_ids = [item.get("locus_id") for item in presences if isinstance(item, dict)]
        if len(locus_ids) != len(presences) or len(set(locus_ids)) != len(locus_ids):
            raise KentraError("invalid or duplicate active Presence")
        residues = state.get("incorporated_residues")
        if not isinstance(residues, list) or len(set(residues)) != len(residues):
            raise KentraError("invalid residue state")
        for digest in residues:
            require_sha256(digest, "residue digest")
            path = self.root / "residues" / f"{digest}.json"
            value = read_json(path)
            claimed = value.get("residue_sha256")
            unhashed = {key: item for key, item in value.items() if key != "residue_sha256"}
            if claimed != digest or sha256_value(unhashed) != digest:
                raise KentraError("incorporated residue mismatch")
        return {
            "status": "VALID",
            "locality_id": locality_id,
            "revision": state["revision"],
            "journal_tip_sha256": expected_tip,
            "carrier_status": carrier["carrier_status"],
        }


class LocusField:
    """One Host-accountable temporary field with no independent Agency."""

    def __init__(self, root: Path):
        self.root = root
        self.field_path = root / "field.json"
        self.state_path = root / "state.json"
        self.journal_path = root / "journal.jsonl"

    @classmethod
    def open(
        cls,
        root: Path,
        *,
        host: LocalityCarrier,
        locus_id: str,
        basis: str,
        scope: str,
        closure_condition: str,
    ) -> "LocusField":
        host.verify()
        if not all((locus_id, basis, scope, closure_condition)):
            raise KentraError("Locus-Field basis, scope and closure are required")
        ensure_new_root(root)
        host_carrier = host.carrier
        field = {
            "schema": "kentra.locus-field.v0.1",
            "locus_id": locus_id,
            "host": {
                "locality_id": host.locality_id,
                "source_sha256": host_carrier["source"]["sha256"],
                "form_sha256": host_carrier["form"]["sha256"],
            },
            "basis": basis,
            "scope": scope,
            "closure_condition": closure_condition,
            "form_id": host_carrier["form"]["id"],
            "effect_ceiling": [
                "NO_INDEPENDENT_FIELD_AGENCY",
                "NO_LOCALITY_OR_CORE_OWNERSHIP",
                "NO_AUTOMATIC_MATTER_ADMISSION",
                "NO_AUTOMATIC_LOCAL_UPTAKE",
                "NO_SHARED_CURRENTNESS",
            ],
        }
        state = {
            "schema": "kentra.locus-field-state.v0.1",
            "locus_id": locus_id,
            "revision": 0,
            "journal_tip_sha256": None,
            "status": "OPEN",
            "present_locality_ids": [host.locality_id],
            "participant_locality_ids": [host.locality_id],
            "presentations": {},
            "gate_decisions": {},
            "matter": {},
            "emergence": [],
        }
        write_json(root / "field.json", field)
        write_json(root / "state.json", state)
        instance = cls(root)
        instance._record(
            "FIELD_BOUND",
            {
                "field_sha256": sha256_file(root / "field.json"),
                "host_locality_id": host.locality_id,
                "basis": basis,
                "scope": scope,
                "closure_condition": closure_condition,
            },
        )
        host.bind_presence(locus_id, "HOST")
        host.record_field_occurrence(
            "LOCUS_FIELD_OPENED",
            {"locus_id": locus_id, "role": "HOST", "field_owns_locality": False},
        )
        instance.verify()
        return instance

    @property
    def field(self) -> dict[str, Any]:
        return read_json(self.field_path)

    @property
    def state(self) -> dict[str, Any]:
        return read_json(self.state_path)

    @property
    def locus_id(self) -> str:
        return str(self.field["locus_id"])

    @property
    def host_locality_id(self) -> str:
        return str(self.field["host"]["locality_id"])

    def _require_open(self) -> None:
        if self.state.get("status") != "OPEN":
            raise KentraError("Locus-Field is closed")

    def _require_host(self, locality: LocalityCarrier) -> None:
        locality.verify()
        if locality.locality_id != self.host_locality_id:
            raise KentraError("only the Host Locality may perform this operation")

    def _require_present(self, locality: LocalityCarrier) -> None:
        locality.verify()
        if locality.locality_id not in self.state["present_locality_ids"]:
            raise KentraError("Locality is not present in this Locus-Field")

    def _record(
        self,
        event_type: str,
        data: dict[str, Any],
        mutate: StateMutator | None = None,
    ) -> dict[str, Any]:
        self.verify(allow_empty_journal=True)
        if "resulting_state_sha256" in data:
            raise KentraError("resulting_state_sha256 is runtime-reserved")
        state = self.state
        state["revision"] = int(state["revision"]) + 1
        if mutate is not None:
            mutate(state)
        committed_data = {
            **data,
            "resulting_state_sha256": mutable_state_sha256(state),
        }
        entry = append_journal(
            self.journal_path,
            "LOCUS_FIELD",
            self.locus_id,
            event_type,
            committed_data,
        )
        state["journal_tip_sha256"] = entry["entry_sha256"]
        write_json(self.state_path, state)
        return entry

    def present(self, entrant: LocalityCarrier) -> str:
        self._require_open()
        entrant.verify()
        if entrant.locality_id == self.host_locality_id:
            raise KentraError("Host does not enter through an Entrant presentation")
        if entrant.locality_id in self.state["present_locality_ids"]:
            raise KentraError("Locality is already present")
        presentation = entrant.present_form(self.locus_id)
        presentation_id = str(presentation["presentation_sha256"])
        path = self.root / "presentations" / f"{presentation_id}.json"
        write_json(path, presentation)

        def mutate(state: dict[str, Any]) -> None:
            state["presentations"][presentation_id] = {
                "locality_id": entrant.locality_id,
                "path": path.relative_to(self.root).as_posix(),
                "sha256": sha256_file(path),
            }
            state["gate_decisions"][presentation_id] = []

        self._record(
            "FORM_PRESENTED",
            {
                "presentation_id": presentation_id,
                "entrant_locality_id": entrant.locality_id,
                "admission_created": False,
                "presence_created": False,
            },
            mutate,
        )
        return presentation_id

    def gate(
        self,
        host: LocalityCarrier,
        presentation_id: str,
        disposition: str,
        basis: str,
    ) -> None:
        self._require_open()
        self._require_host(host)
        if disposition not in GATE_POSTURES:
            raise KentraError("invalid Gate disposition")
        state = self.state
        if presentation_id not in state["presentations"]:
            raise KentraError("unknown Form presentation")
        decisions = state["gate_decisions"][presentation_id]
        predecessor = decisions[-1]["disposition"] if decisions else None
        decision = {
            "decision_id": f"gate-{time.time_ns()}-{secrets.token_hex(4)}",
            "disposition": disposition,
            "basis": basis,
            "host_locality_id": host.locality_id,
            "predecessor_disposition": predecessor,
        }

        def mutate(current: dict[str, Any]) -> None:
            current["gate_decisions"][presentation_id].append(decision)

        self._record(
            "GATE_DISPOSITION_RECORDED",
            {"presentation_id": presentation_id, **decision},
            mutate,
        )
        host.record_field_occurrence(
            "HOST_GATE_DISPOSITION_ORIGINATED",
            {
                "locus_id": self.locus_id,
                "presentation_id": presentation_id,
                "disposition": disposition,
            },
        )

    def enter(self, entrant: LocalityCarrier, presentation_id: str) -> None:
        self._require_open()
        entrant.verify()
        state = self.state
        presentation_meta = state["presentations"].get(presentation_id)
        if not presentation_meta:
            raise KentraError("unknown Form presentation")
        if presentation_meta["locality_id"] != entrant.locality_id:
            raise KentraError("presentation belongs to another Locality")
        decisions = state["gate_decisions"].get(presentation_id, [])
        if not decisions or decisions[-1]["disposition"] != "ADMIT":
            raise KentraError("actual Entry requires current Host ADMIT")
        presentation_path = self.root / presentation_meta["path"]
        presentation = read_json(presentation_path)
        claimed = presentation.pop("presentation_sha256", None)
        if claimed != presentation_id or sha256_value(presentation) != presentation_id:
            raise KentraError("Form presentation identity mismatch")
        if presentation["current_state_commitment"] != entrant.state_commitment():
            raise KentraError("Entrant state changed after presentation")
        if entrant.locality_id in state["present_locality_ids"]:
            raise KentraError("Entrant is already present")

        def mutate(current: dict[str, Any]) -> None:
            current["present_locality_ids"].append(entrant.locality_id)
            if entrant.locality_id not in current["participant_locality_ids"]:
                current["participant_locality_ids"].append(entrant.locality_id)

        self._record(
            "ENTRY_OCCURRED",
            {
                "presentation_id": presentation_id,
                "entrant_locality_id": entrant.locality_id,
                "presence_created": True,
                "matter_admission_created": False,
            },
            mutate,
        )
        entrant.bind_presence(self.locus_id, "ENTRANT")
        entrant.record_field_occurrence(
            "ENTRY_ORIGINATED",
            {"locus_id": self.locus_id, "presentation_id": presentation_id},
        )

    def cross_matter(
        self,
        actor: LocalityCarrier,
        payload: bytes,
        *,
        content_type: str,
        claim: str,
    ) -> str:
        self._require_open()
        self._require_present(actor)
        digest = sha256_bytes(payload)
        matter_id = f"matter-{time.time_ns()}-{digest[:12]}"
        path = self.root / "matter" / f"{matter_id}.bin"
        atomic_write(path, payload)
        record = {
            "matter_id": matter_id,
            "originating_locality_id": actor.locality_id,
            "content_type": content_type,
            "claim": claim,
            "wire_bytes": len(payload),
            "wire_sha256": digest,
            "raw_carrier": path.relative_to(self.root).as_posix(),
            "dispositions": {},
        }

        def mutate(state: dict[str, Any]) -> None:
            state["matter"][matter_id] = record

        self._record(
            "CROSSING_OBSERVED",
            {
                "matter_id": matter_id,
                "originating_locality_id": actor.locality_id,
                "wire_sha256": digest,
                "matter_admission_created": False,
                "truth_determined": False,
            },
            mutate,
        )
        actor.record_field_occurrence(
            "MATTER_CROSSING_ORIGINATED",
            {"locus_id": self.locus_id, "matter_id": matter_id, "wire_sha256": digest},
        )
        return matter_id

    def matter_disposition(
        self,
        locality: LocalityCarrier,
        matter_id: str,
        disposition: str,
        basis: str,
    ) -> None:
        self._require_open()
        self._require_present(locality)
        if disposition not in GATE_POSTURES:
            raise KentraError("invalid Matter disposition")
        state = self.state
        if matter_id not in state["matter"]:
            raise KentraError("unknown Matter crossing")
        decision = {
            "disposition": disposition,
            "basis": basis,
            "recorded_at": utc_now(),
        }

        def mutate(current: dict[str, Any]) -> None:
            decisions = current["matter"][matter_id]["dispositions"].setdefault(
                locality.locality_id, []
            )
            decisions.append(decision)

        self._record(
            "MATTER_DISPOSITION_RECORDED",
            {
                "matter_id": matter_id,
                "locality_id": locality.locality_id,
                **decision,
            },
            mutate,
        )
        locality.record_field_occurrence(
            "LOCAL_MATTER_DISPOSITION_ORIGINATED",
            {
                "locus_id": self.locus_id,
                "matter_id": matter_id,
                "disposition": disposition,
            },
        )

    def emerge(
        self,
        *,
        contributor_localities: list[LocalityCarrier],
        matter_ids: list[str],
        kind: str,
        description: str,
    ) -> str:
        self._require_open()
        if len({item.locality_id for item in contributor_localities}) < 2:
            raise KentraError("Emergence requires at least two distinct present Localities")
        for locality in contributor_localities:
            self._require_present(locality)
        state = self.state
        contributor_ids = [item.locality_id for item in contributor_localities]
        for matter_id in matter_ids:
            if matter_id not in state["matter"]:
                raise KentraError("Emergence references unknown Matter")
            dispositions = state["matter"][matter_id]["dispositions"]
            for locality_id in contributor_ids:
                decisions = dispositions.get(locality_id, [])
                if not decisions or decisions[-1]["disposition"] != "ADMIT":
                    raise KentraError("Emergence requires participant-local Matter admission")
        body = {
            "contributors": contributor_ids,
            "matter_ids": matter_ids,
            "kind": kind,
            "description": description,
            "recorded_at": utc_now(),
        }
        emergence_id = f"emergence-{sha256_value(body)[:24]}"
        record = {"emergence_id": emergence_id, **body}

        def mutate(current: dict[str, Any]) -> None:
            current["emergence"].append(record)

        self._record("EMERGENCE_RECORDED", record, mutate)
        return emergence_id

    def exit(self, entrant: LocalityCarrier, reason: str) -> None:
        self._require_open()
        self._require_present(entrant)
        if entrant.locality_id == self.host_locality_id:
            raise KentraError("Host Presence ends through field closure")

        def mutate(state: dict[str, Any]) -> None:
            state["present_locality_ids"].remove(entrant.locality_id)

        self._record(
            "ENTRANT_EXITED",
            {"entrant_locality_id": entrant.locality_id, "reason": reason},
            mutate,
        )
        entrant.unbind_presence(self.locus_id, reason)

    def close(self, host: LocalityCarrier, basis: str) -> dict[str, Path]:
        self._require_open()
        self._require_host(host)
        state = self.state
        if state["present_locality_ids"] != [host.locality_id]:
            raise KentraError("all Entrants must exit before Host closure")

        def mutate(current: dict[str, Any]) -> None:
            current["status"] = "CLOSED"
            current["present_locality_ids"] = []

        entry = self._record(
            "FIELD_CLOSED",
            {"host_locality_id": host.locality_id, "basis": basis},
            mutate,
        )
        host.unbind_presence(self.locus_id, "HOST_CLOSURE")
        host.record_field_occurrence(
            "LOCUS_FIELD_CLOSURE_OBSERVED",
            {"locus_id": self.locus_id, "field_journal_tip_sha256": entry["entry_sha256"]},
        )
        final_state = self.state
        residue_paths: dict[str, Path] = {}
        for locality_id in final_state["participant_locality_ids"]:
            admitted_matter = []
            for matter_id, matter in final_state["matter"].items():
                decisions = matter["dispositions"].get(locality_id, [])
                if decisions and decisions[-1]["disposition"] == "ADMIT":
                    admitted_matter.append(matter_id)
            residue_without_hash = {
                "schema": "kentra.addressed-residue.v0.1",
                "locus_id": self.locus_id,
                "field_status": "CLOSED",
                "addressed_locality_id": locality_id,
                "field_journal_tip_sha256": final_state["journal_tip_sha256"],
                "admitted_matter_ids": admitted_matter,
                "emergence_ids": [item["emergence_id"] for item in final_state["emergence"]],
                "automatic_local_uptake": False,
                "field_claims_receiver_incorporation": False,
            }
            residue = {
                **residue_without_hash,
                "residue_sha256": sha256_value(residue_without_hash),
            }
            path = addressed_residue_path(self.root, locality_id)
            write_json(path, residue)
            residue_paths[locality_id] = path
        self.verify()
        return residue_paths

    def verify(self, *, allow_empty_journal: bool = False) -> dict[str, Any]:
        for path in (self.field_path, self.state_path):
            if not path.is_file():
                raise KentraError(f"missing Locus-Field file: {path.name}")
        field = self.field
        if field.get("schema") != "kentra.locus-field.v0.1":
            raise KentraError("Locus-Field schema mismatch")
        locus_id = field.get("locus_id")
        if not isinstance(locus_id, str) or not locus_id:
            raise KentraError("Locus identity missing")
        require_sha256(field["host"]["source_sha256"], "host source")
        require_sha256(field["host"]["form_sha256"], "host Form")
        entries = verify_journal(self.journal_path, "LOCUS_FIELD", locus_id)
        if not entries and not allow_empty_journal:
            raise KentraError("Locus-Field journal is empty")
        state = self.state
        if state.get("schema") != "kentra.locus-field-state.v0.1":
            raise KentraError("Locus-Field state schema mismatch")
        if state.get("locus_id") != locus_id:
            raise KentraError("Locus-Field state identity mismatch")
        if state.get("revision") != len(entries):
            raise KentraError("Locus-Field revision does not match journal")
        expected_tip = entries[-1]["entry_sha256"] if entries else None
        if state.get("journal_tip_sha256") != expected_tip:
            raise KentraError("Locus-Field journal tip mismatch")
        if entries:
            first = entries[0]
            if first.get("event_type") != "FIELD_BOUND":
                raise KentraError("Locus-Field journal lacks binding root")
            if first.get("data", {}).get("field_sha256") != sha256_file(
                self.field_path
            ):
                raise KentraError("Locus-Field root commitment mismatch")
            if entries[-1].get("data", {}).get(
                "resulting_state_sha256"
            ) != mutable_state_sha256(state):
                raise KentraError("Locus-Field state commitment mismatch")
        if state.get("status") not in {"OPEN", "CLOSED"}:
            raise KentraError("invalid Locus-Field status")
        present = state.get("present_locality_ids")
        participants = state.get("participant_locality_ids")
        if not isinstance(present, list) or len(set(present)) != len(present):
            raise KentraError("invalid present Locality set")
        if not isinstance(participants, list) or len(set(participants)) != len(participants):
            raise KentraError("invalid participant history")
        if not set(present).issubset(set(participants)):
            raise KentraError("present Locality missing from participant history")
        if field["host"]["locality_id"] not in participants:
            raise KentraError("Host missing from participant history")
        if state["status"] == "OPEN" and field["host"]["locality_id"] not in present:
            raise KentraError("open field lacks Host Presence")
        if state["status"] == "CLOSED" and present:
            raise KentraError("closed field retains Presence")
        for presentation_id, meta in state.get("presentations", {}).items():
            path = self.root / meta["path"]
            if sha256_file(path) != meta["sha256"]:
                raise KentraError("stored Form presentation changed")
            presentation = read_json(path)
            claimed = presentation.pop("presentation_sha256", None)
            if claimed != presentation_id or sha256_value(presentation) != presentation_id:
                raise KentraError("presentation digest mismatch")
        for presentation_id, decisions in state.get("gate_decisions", {}).items():
            if presentation_id not in state.get("presentations", {}):
                raise KentraError("Gate decision references unknown presentation")
            if not isinstance(decisions, list):
                raise KentraError("Gate decision history must be a list")
            for decision in decisions:
                if decision.get("disposition") not in GATE_POSTURES:
                    raise KentraError("invalid preserved Gate disposition")
        for matter_id, matter in state.get("matter", {}).items():
            if matter.get("matter_id") != matter_id:
                raise KentraError("Matter identity mismatch")
            raw = self.root / matter["raw_carrier"]
            if not raw.is_file() or raw.stat().st_size != matter["wire_bytes"]:
                raise KentraError("Matter carrier length mismatch")
            if sha256_file(raw) != matter["wire_sha256"]:
                raise KentraError("Matter carrier hash mismatch")
            for locality_id, decisions in matter.get("dispositions", {}).items():
                if locality_id not in participants or not isinstance(decisions, list):
                    raise KentraError("invalid Matter disposition owner")
                for decision in decisions:
                    if decision.get("disposition") not in GATE_POSTURES:
                        raise KentraError("invalid Matter disposition")
        emergence_ids: set[str] = set()
        for emergence in state.get("emergence", []):
            emergence_id = emergence.get("emergence_id")
            if not isinstance(emergence_id, str) or emergence_id in emergence_ids:
                raise KentraError("invalid or duplicate Emergence")
            if not set(emergence.get("contributors", [])).issubset(set(participants)):
                raise KentraError("Emergence contributor is not a participant")
            if not set(emergence.get("matter_ids", [])).issubset(set(state["matter"])):
                raise KentraError("Emergence references unknown Matter")
            emergence_ids.add(emergence_id)
        if state["status"] == "CLOSED":
            for locality_id in participants:
                path = addressed_residue_path(self.root, locality_id)
                residue = read_json(path)
                claimed = residue.get("residue_sha256")
                unhashed = {key: value for key, value in residue.items() if key != "residue_sha256"}
                if claimed != sha256_value(unhashed):
                    raise KentraError("addressed residue hash mismatch")
                if residue.get("addressed_locality_id") != locality_id:
                    raise KentraError("addressed residue owner mismatch")
                if residue.get("field_journal_tip_sha256") != expected_tip:
                    raise KentraError("residue does not bind final field journal")
                admitted_matter = []
                for matter_id, matter in state["matter"].items():
                    decisions = matter["dispositions"].get(locality_id, [])
                    if decisions and decisions[-1]["disposition"] == "ADMIT":
                        admitted_matter.append(matter_id)
                expected_residue = {
                    "schema": "kentra.addressed-residue.v0.1",
                    "locus_id": self.locus_id,
                    "field_status": "CLOSED",
                    "addressed_locality_id": locality_id,
                    "field_journal_tip_sha256": expected_tip,
                    "admitted_matter_ids": admitted_matter,
                    "emergence_ids": [
                        item["emergence_id"] for item in state["emergence"]
                    ],
                    "automatic_local_uptake": False,
                    "field_claims_receiver_incorporation": False,
                }
                if unhashed != expected_residue:
                    raise KentraError("addressed residue content mismatch")
        return {
            "status": "VALID",
            "locus_id": locus_id,
            "field_status": state["status"],
            "revision": state["revision"],
            "journal_tip_sha256": expected_tip,
            "participant_count": len(participants),
            "matter_count": len(state.get("matter", {})),
            "emergence_count": len(state.get("emergence", [])),
        }


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify KENTRA_001 reference carriers")
    subparsers = parser.add_subparsers(dest="command", required=True)
    locality_parser = subparsers.add_parser("verify-locality")
    locality_parser.add_argument("root", type=Path)
    field_parser = subparsers.add_parser("verify-field")
    field_parser.add_argument("root", type=Path)
    args = parser.parse_args()
    if args.command == "verify-locality":
        result = LocalityCarrier(args.root).verify()
    else:
        result = LocusField(args.root).verify()
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
