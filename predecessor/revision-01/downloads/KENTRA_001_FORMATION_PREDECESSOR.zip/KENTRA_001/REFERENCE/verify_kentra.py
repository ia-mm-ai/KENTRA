#!/usr/bin/env python3
"""Pressure verification for the KENTRA_001 working reference.

The verifier exercises bounded reference carriers.  A PASS demonstrates that
the implementation preserves the declared distinctions under these tests; it
does not establish formation, Authority, identity, or an actual live field.
"""

from __future__ import annotations

import argparse
import json
import shutil
import tempfile
from pathlib import Path
from typing import Any, Callable

from kentra import (
    DEFAULT_FORM_PATH,
    KentraError,
    LocalityCarrier,
    LocusField,
    canonical_bytes,
    load_form,
    read_json,
    sha256_bytes,
    sha256_file,
    sha256_value,
    write_json,
)


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
LINEAGE_PATH = PACKAGE_ROOT / "EXAMPLES" / "CONTINUITY_LINEAGE_CANDIDATE_001.json"


class Pressure:
    def __init__(self) -> None:
        self.checks: list[dict[str, str]] = []

    def check(self, check_id: str, condition: bool, evidence: str) -> None:
        if not condition:
            raise AssertionError(f"{check_id}: {evidence}")
        self.checks.append({"id": check_id, "status": "PASS", "evidence": evidence})

    def expect_kentra_error(
        self,
        check_id: str,
        action: Callable[[], Any],
        expected_fragment: str,
    ) -> str:
        try:
            action()
        except KentraError as exc:
            message = str(exc)
            if expected_fragment not in message:
                raise AssertionError(
                    f"{check_id}: expected {expected_fragment!r}, received {message!r}"
                ) from exc
            self.checks.append(
                {
                    "id": check_id,
                    "status": "PASS",
                    "evidence": f"blocked with: {message}",
                }
            )
            return message
        raise AssertionError(f"{check_id}: operation was not blocked")


def source_lineage_checks(pressure: Pressure) -> dict[str, Any]:
    candidate = read_json(LINEAGE_PATH)
    origin = candidate["origin_locality"]
    derived = candidate["derived_locality"]
    origin_source_hash = sha256_bytes(origin["source_utf8"].encode("utf-8"))
    origin_state_hash = sha256_bytes(origin["accepted_genesis_state_utf8"].encode("utf-8"))
    derived_source_hash = sha256_bytes(derived["source_utf8"].encode("utf-8"))

    pressure.check(
        "LINEAGE-01",
        candidate["status"] == "PREPARED_NOT_INSTANTIATED",
        "lineage remains a prepared candidate, not a formation claim",
    )
    pressure.check(
        "LINEAGE-02",
        origin_source_hash == origin["source_sha256"],
        "CONTINUITY source bytes match the recorded digest",
    )
    pressure.check(
        "LINEAGE-03",
        origin_state_hash == origin["accepted_genesis_state_sha256"],
        "CONTINUITY accepted genesis state matches the recorded digest",
    )
    pressure.check(
        "LINEAGE-04",
        derived_source_hash == derived["source_sha256"],
        "LIVE-STATE source bytes match the recorded digest",
    )
    pressure.check(
        "LINEAGE-05",
        origin["accepted_genesis_state_utf8"] == derived["source_utf8"]
        and origin["accepted_genesis_state_sha256"] == derived["source_sha256"],
        "the exact accepted origin state is the exact derived source",
    )
    pressure.check(
        "LINEAGE-06",
        origin["locality_id"] != derived["locality_id"],
        "lineage preserves distinct Locality identities",
    )
    return candidate


def create_lineage_carriers(
    root: Path,
    candidate: dict[str, Any],
    *,
    prefix: str,
) -> tuple[LocalityCarrier, LocalityCarrier]:
    origin = candidate["origin_locality"]
    derived = candidate["derived_locality"]
    host = LocalityCarrier.create(
        root / f"{prefix}-host",
        locality_id=f"{origin['locality_id']}::{prefix}",
        source_reference="CONTINUITY/source",
        source_sha256=origin["source_sha256"],
        lineage=None,
    )
    entrant = LocalityCarrier.create(
        root / f"{prefix}-entrant",
        locality_id=f"{derived['locality_id']}::{prefix}",
        source_reference="LIVE-STATE-1822-17092026-MM22/source",
        source_sha256=derived["source_sha256"],
        lineage={
            "relation": candidate["relation"],
            "parent_locality_id": origin["locality_id"],
            "parent_state_sha256": origin["accepted_genesis_state_sha256"],
        },
    )
    return host, entrant


def pressure_crossing(
    pressure: Pressure,
    root: Path,
    candidate: dict[str, Any],
) -> dict[str, Any]:
    form, form_sha256 = load_form(DEFAULT_FORM_PATH)
    pressure.check(
        "FORM-01",
        form["status"] == "WORKING_REFERENCE_NON_CONSTITUTIVE",
        "public Form states its non-constitutive ceiling",
    )
    pressure.check(
        "FORM-02",
        "ADMISSION_NOT_ENTRY" in form["non_collapse_rules"],
        "admission and actual Entry remain distinct",
    )
    pressure.check(
        "FORM-03",
        "ENTRY_NOT_MATTER_ADMISSION" in form["non_collapse_rules"],
        "Entry and Matter admission remain distinct",
    )

    host, entrant = create_lineage_carriers(root, candidate, prefix="crossing")
    pressure.check(
        "CARRIER-01",
        host.locality_id != entrant.locality_id,
        "Host and Entrant remain separately identified Localities",
    )
    pressure.check(
        "CARRIER-02",
        host.carrier["form"] == entrant.carrier["form"],
        "distinct Localities can expose the same KENTRA Form",
    )
    pressure.check(
        "CARRIER-03",
        host.carrier["source"]["sha256"] != entrant.carrier["source"]["sha256"],
        "shared Form does not collapse distinct Source commitments",
    )

    locus = LocusField.open(
        root / "crossing-field",
        host=host,
        locus_id="KENTRA-PRESSURE-FIELD-001",
        basis="bounded KENTRA crossing pressure",
        scope="reference-only admission, relation, closure, and residue",
        closure_condition="Entrant exits and Host explicitly closes",
    )
    pressure.check(
        "BOUND-01",
        locus.state["present_locality_ids"] == [host.locality_id],
        "opening binds Host Presence only",
    )
    pressure.check(
        "BOUND-02",
        any(item["locus_id"] == locus.locus_id for item in host.state["active_presences"]),
        "Host locally records its bounded Presence",
    )

    presentation_id = locus.present(entrant)
    pressure.check(
        "PRESENT-01",
        entrant.locality_id not in locus.state["present_locality_ids"],
        "Form presentation creates neither Entry nor Presence",
    )
    pressure.check(
        "PRESENT-02",
        entrant.state["active_presences"] == [],
        "Entrant remains locally unbound after presentation",
    )

    pressure.expect_kentra_error(
        "GATE-01",
        lambda: locus.gate(entrant, presentation_id, "ADMIT", "unauthorized attempt"),
        "only the Host Locality",
    )
    locus.gate(host, presentation_id, "HOLD", "insufficient basis for Entry")
    pressure.expect_kentra_error(
        "GATE-02",
        lambda: locus.enter(entrant, presentation_id),
        "requires current Host ADMIT",
    )
    pressure.check(
        "GATE-03",
        entrant.locality_id not in locus.state["present_locality_ids"],
        "HOLD preserves non-Presence",
    )
    locus.gate(host, presentation_id, "ADMIT", "bounded participation accepted")
    pressure.check(
        "ENTRY-01",
        entrant.locality_id not in locus.state["present_locality_ids"],
        "ADMIT alone still does not create Entry",
    )
    locus.enter(entrant, presentation_id)
    pressure.check(
        "ENTRY-02",
        entrant.locality_id in locus.state["present_locality_ids"],
        "explicit Entry creates field Presence",
    )
    pressure.check(
        "ENTRY-03",
        any(item["locus_id"] == locus.locus_id for item in entrant.state["active_presences"]),
        "Entrant independently records its own Presence",
    )

    matter_id = locus.cross_matter(
        entrant,
        b"KENTRA crossing: offered Matter is not admitted Matter.",
        content_type="text/plain; charset=utf-8",
        claim="offered reference Matter",
    )
    pressure.check(
        "MATTER-01",
        locus.state["matter"][matter_id]["dispositions"] == {},
        "crossing records Matter without admitting it anywhere",
    )
    pressure.expect_kentra_error(
        "EMERGENCE-01",
        lambda: locus.emerge(
            contributor_localities=[host, entrant],
            matter_ids=[matter_id],
            kind="REFERENCE_RELATION",
            description="must not emerge before reciprocal admission",
        ),
        "participant-local Matter admission",
    )
    locus.matter_disposition(host, matter_id, "ADMIT", "Host-local admission")
    pressure.expect_kentra_error(
        "EMERGENCE-02",
        lambda: locus.emerge(
            contributor_localities=[host, entrant],
            matter_ids=[matter_id],
            kind="REFERENCE_RELATION",
            description="one-sided admission remains insufficient",
        ),
        "participant-local Matter admission",
    )
    locus.matter_disposition(entrant, matter_id, "ADMIT", "Entrant-local admission")
    emergence_id = locus.emerge(
        contributor_localities=[host, entrant],
        matter_ids=[matter_id],
        kind="REFERENCE_RELATION",
        description="bounded relation after reciprocal local admission",
    )
    pressure.check(
        "EMERGENCE-03",
        locus.state["emergence"][-1]["emergence_id"] == emergence_id,
        "Emergence becomes recordable only after reciprocal local admission",
    )
    pressure.check(
        "EMERGENCE-04",
        len(locus.state["emergence"][-1]["contributors"]) == 2,
        "Emergence preserves both distinct contributors",
    )
    pressure.check(
        "RESIDUE-01",
        not (locus.root / "residues").exists(),
        "no addressed residue exists before closure",
    )

    locus.exit(entrant, "bounded participation complete")
    pressure.check(
        "EXIT-01",
        entrant.locality_id not in locus.state["present_locality_ids"],
        "Entrant exit removes only Entrant field Presence",
    )
    pressure.check(
        "EXIT-02",
        locus.state["present_locality_ids"] == [host.locality_id],
        "Host remains present until explicit closure",
    )
    residue_paths = locus.close(host, "declared closure condition satisfied")
    pressure.check(
        "CLOSE-01",
        locus.state["status"] == "CLOSED" and locus.state["present_locality_ids"] == [],
        "closure ends all field Presence",
    )
    pressure.check(
        "CLOSE-02",
        host.state["active_presences"] == [] and entrant.state["active_presences"] == [],
        "each Locality remains independently unbound after closure",
    )
    pressure.check(
        "RESIDUE-02",
        set(residue_paths) == {host.locality_id, entrant.locality_id},
        "closure emits separately addressed residue for both participants",
    )
    pressure.expect_kentra_error(
        "CLOSE-03",
        lambda: locus.cross_matter(
            host,
            b"late crossing",
            content_type="text/plain",
            claim="must fail",
        ),
        "closed",
    )
    pressure.expect_kentra_error(
        "RESIDUE-03",
        lambda: host.incorporate_residue(residue_paths[entrant.locality_id]),
        "addressed to another Locality",
    )

    entrant_before_host_uptake = sha256_file(entrant.state_path)
    host_before_uptake = sha256_file(host.state_path)
    host_residue = host.incorporate_residue(residue_paths[host.locality_id])
    pressure.check(
        "INDEPENDENCE-01",
        sha256_file(entrant.state_path) == entrant_before_host_uptake,
        "Host uptake does not mutate Entrant currentness",
    )
    pressure.check(
        "INDEPENDENCE-02",
        sha256_file(host.state_path) != host_before_uptake,
        "Host uptake changes Host-local state only",
    )
    entrant_residue = entrant.incorporate_residue(residue_paths[entrant.locality_id])
    pressure.check(
        "INDEPENDENCE-03",
        host_residue != entrant_residue,
        "addressed residues retain distinct local custody",
    )
    pressure.check(
        "VERIFY-01",
        locus.verify()["status"] == "VALID"
        and host.verify()["status"] == "VALID"
        and entrant.verify()["status"] == "VALID",
        "closed field and independently advanced carriers verify",
    )

    return {
        "form_sha256": form_sha256,
        "locus_id": locus.locus_id,
        "host_locality_id": host.locality_id,
        "entrant_locality_id": entrant.locality_id,
        "matter_id": matter_id,
        "emergence_id": emergence_id,
        "field_journal_tip_sha256": locus.state["journal_tip_sha256"],
        "host_final_revision": host.state["revision"],
        "entrant_final_revision": entrant.state["revision"],
        "host_residue_sha256": host_residue,
        "entrant_residue_sha256": entrant_residue,
    }


def pressure_refusal(
    pressure: Pressure,
    root: Path,
    candidate: dict[str, Any],
) -> dict[str, Any]:
    host, entrant = create_lineage_carriers(root, candidate, prefix="refusal")
    locus = LocusField.open(
        root / "refusal-field",
        host=host,
        locus_id="KENTRA-REFUSAL-FIELD-001",
        basis="refusal must remain effective",
        scope="presentation and refusal only",
        closure_condition="Host records refusal and closes",
    )
    presentation_id = locus.present(entrant)
    locus.gate(host, presentation_id, "REFUSE", "scope not admitted")
    pressure.expect_kentra_error(
        "REFUSAL-01",
        lambda: locus.enter(entrant, presentation_id),
        "requires current Host ADMIT",
    )
    pressure.check(
        "REFUSAL-02",
        entrant.locality_id not in locus.state["participant_locality_ids"],
        "refused presenter never becomes a participant",
    )
    pressure.check(
        "REFUSAL-03",
        entrant.state["active_presences"] == [],
        "refusal creates no Entrant Presence",
    )
    residue_paths = locus.close(host, "refusal completed the bounded scope")
    pressure.check(
        "REFUSAL-04",
        set(residue_paths) == {host.locality_id},
        "refused non-participant receives no field residue",
    )
    pressure.check(
        "REFUSAL-05",
        locus.verify()["status"] == "VALID",
        "refused-and-closed field verifies",
    )
    return {
        "locus_id": locus.locus_id,
        "field_journal_tip_sha256": locus.state["journal_tip_sha256"],
    }


def pressure_tamper(
    pressure: Pressure,
    root: Path,
    crossing: dict[str, Any],
) -> None:
    source_field = root / "crossing-field"
    source_host = root / "crossing-host"

    tampered_journal = root / "tampered-field-journal"
    shutil.copytree(source_field, tampered_journal)
    journal_path = tampered_journal / "journal.jsonl"
    lines = journal_path.read_text(encoding="utf-8").splitlines()
    first = json.loads(lines[0])
    first["event_type"] = "TAMPERED_EVENT"
    lines[0] = canonical_bytes(first).decode("utf-8")
    journal_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    pressure.expect_kentra_error(
        "TAMPER-01",
        lambda: LocusField(tampered_journal).verify(),
        "journal entry hash mismatch",
    )

    tampered_state = root / "tampered-locality-state"
    shutil.copytree(source_host, tampered_state)
    state = read_json(tampered_state / "state.json")
    state["revision"] += 1
    write_json(tampered_state / "state.json", state)
    pressure.expect_kentra_error(
        "TAMPER-02",
        lambda: LocalityCarrier(tampered_state).verify(),
        "revision does not match journal",
    )

    tampered_matter = root / "tampered-field-matter"
    shutil.copytree(source_field, tampered_matter)
    matter_path = tampered_matter / LocusField(tampered_matter).state["matter"][
        crossing["matter_id"]
    ]["raw_carrier"]
    matter_path.write_bytes(matter_path.read_bytes() + b"tamper")
    pressure.expect_kentra_error(
        "TAMPER-03",
        lambda: LocusField(tampered_matter).verify(),
        "Matter carrier length mismatch",
    )

    tampered_presentation = root / "tampered-field-presentation"
    shutil.copytree(source_field, tampered_presentation)
    field_state = LocusField(tampered_presentation).state
    presentation_meta = next(iter(field_state["presentations"].values()))
    presentation_path = tampered_presentation / presentation_meta["path"]
    presentation = read_json(presentation_path)
    presentation["presented_at"] = "TAMPERED"
    write_json(presentation_path, presentation)
    pressure.expect_kentra_error(
        "TAMPER-04",
        lambda: LocusField(tampered_presentation).verify(),
        "stored Form presentation changed",
    )

    tampered_carrier = root / "tampered-locality-carrier"
    shutil.copytree(source_host, tampered_carrier)
    carrier = read_json(tampered_carrier / "carrier.json")
    carrier["source"]["sha256"] = "0" * 64
    write_json(tampered_carrier / "carrier.json", carrier)
    pressure.expect_kentra_error(
        "TAMPER-05",
        lambda: LocalityCarrier(tampered_carrier).verify(),
        "carrier root commitment mismatch",
    )

    tampered_field_root = root / "tampered-field-root"
    shutil.copytree(source_field, tampered_field_root)
    field = read_json(tampered_field_root / "field.json")
    field["scope"] = "tampered scope"
    write_json(tampered_field_root / "field.json", field)
    pressure.expect_kentra_error(
        "TAMPER-06",
        lambda: LocusField(tampered_field_root).verify(),
        "root commitment mismatch",
    )

    tampered_state_content = root / "tampered-locality-content"
    shutil.copytree(source_host, tampered_state_content)
    state = read_json(tampered_state_content / "state.json")
    state["active_presences"] = [
        {"locus_id": "fabricated-locus", "role": "HOST"}
    ]
    write_json(tampered_state_content / "state.json", state)
    pressure.expect_kentra_error(
        "TAMPER-07",
        lambda: LocalityCarrier(tampered_state_content).verify(),
        "state commitment mismatch",
    )

    tampered_residue = root / "tampered-field-residue"
    shutil.copytree(source_field, tampered_residue)
    residue_path = next((tampered_residue / "residues").glob("*.json"))
    residue = read_json(residue_path)
    residue_without_hash = {
        key: value for key, value in residue.items() if key != "residue_sha256"
    }
    residue_without_hash["automatic_local_uptake"] = True
    write_json(
        residue_path,
        {
            **residue_without_hash,
            "residue_sha256": sha256_value(residue_without_hash),
        },
    )
    pressure.expect_kentra_error(
        "TAMPER-08",
        lambda: LocusField(tampered_residue).verify(),
        "residue content mismatch",
    )


def run() -> dict[str, Any]:
    pressure = Pressure()
    candidate = source_lineage_checks(pressure)
    with tempfile.TemporaryDirectory(prefix="kentra-pressure-") as temporary:
        root = Path(temporary)
        crossing = pressure_crossing(pressure, root, candidate)
        refusal = pressure_refusal(pressure, root, candidate)
        pressure_tamper(pressure, root, crossing)

    return {
        "schema": "kentra.pressure-result.v0.1",
        "test_id": "KENTRA-CROSSING-PRESSURE-001",
        "status": "PASS",
        "check_count": len(pressure.checks),
        "checks": pressure.checks,
        "observed": {
            "crossing": crossing,
            "refusal": refusal,
        },
        "non_effects": [
            "NO_FORMATION_ESTABLISHED",
            "NO_CONSTITUTIONAL_AUTHORITY_ESTABLISHED",
            "NO_BODY_001_MUTATION",
            "NO_CONTINUITY_OR_LIVE_STATE_MUTATION",
            "NO_ACTUAL_LIVE_FIELD_OPENED",
        ],
        "limitations": [
            "REFERENCE_RUNTIME_ONLY",
            "TEMPORARY_FILESYSTEM_SIMULATION",
            "NO_EXTERNAL_IDENTITY_OR_SIGNATURE_VERIFICATION",
            "NO_CLAIM_ABOUT_BEING_OR_BEARER_CONTINUITY",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Pressure-test KENTRA_001")
    parser.add_argument(
        "--compact",
        action="store_true",
        help="emit canonical single-line JSON",
    )
    args = parser.parse_args()
    result = run()
    if args.compact:
        print(canonical_bytes(result).decode("utf-8"))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
