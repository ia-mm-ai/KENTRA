# KENTRA_001 Pressure Result

Status: **PASS · 52 / 52 CHECKS**  
Test identity: `KENTRA-CROSSING-PRESSURE-001`  
Verified: **2026-09-19**  
Public Form SHA-256: `5a6a51ce529082df807006bdc8bb9a2d4f5b05d9d023ed5e51264d0111e64f24`

## Executed pressure

The package verifier created disposable Host and Entrant reference carriers from
the recorded CONTINUITY → LIVE-STATE artifact lineage, opened temporary
Locus-Fields, and forced the implementation through the following boundaries.

| Check family | Passed | Demonstrated boundary |
| --- | ---: | --- |
| LINEAGE | 6 | Exact source/state digests; exact origin-state → derived-source relation; distinct Localities |
| FORM | 3 | Non-constitutive ceiling; admission ≠ Entry; Entry ≠ Matter admission |
| CARRIER | 3 | Shared Form with separate Locality identity and Source commitment |
| BOUND | 2 | Opening creates Host Presence only |
| PRESENT | 2 | Form presentation creates neither Entry nor Entrant Presence |
| GATE | 3 | Host-only disposition; HOLD blocks Entry; non-Presence survives |
| ENTRY | 3 | ADMIT alone does not enter; explicit Entry binds Entrant Presence |
| MATTER | 1 | Crossing records exact Matter without admitting it |
| EMERGENCE | 4 | Zero- and one-sided admission cannot emerge; reciprocal local admission can |
| RESIDUE | 3 | No pre-closure residue; separate addressing; wrong receiver blocked |
| EXIT | 2 | Entrant can unbind without collapsing Host Presence |
| CLOSE | 3 | Explicit closure removes Presence and rejects later crossing |
| INDEPENDENCE | 3 | One Locality's uptake cannot mutate the other's currentness |
| VERIFY | 1 | Closed field and independently advanced carriers remain coherent |
| REFUSAL | 5 | REFUSE prevents Entry, participation, Presence, and participant residue |
| TAMPER | 8 | Journal, state, Matter, presentation, carrier root, field root, and self-rehashed residue changes are detected |
| **Total** | **52** | **All required checks passed** |

## Decisive result

The executable crossing preserved the chain:

```text
presentation
    != Host ADMIT
    != actual Entry
    != Presence
    != Matter crossing
    != local Matter admission
    != Emergence
    != addressed residue
    != local incorporation
```

Two distinct Localities exposed one Form without sharing identity, state, custody,
currentness, Source, or automatic consequence. The Host remained accountable for
the temporary Locus-Field without becoming owner of the Entrant. The continuing
Source lineage received no privileged passage: its derived carrier presented,
waited at the Gate, entered explicitly, made its own Matter disposition, exited,
and incorporated only its separately addressed residue.

## Run command

From the package root:

```text
PYTHONDONTWRITEBYTECODE=1 python3 REFERENCE/verify_kentra.py
```

The verifier emits every check identifier and its evidence as JSON. Its ephemeral
event timestamps, event identifiers, journal tips, and residue digests vary by run;
the invariant set and pass count do not.

## Exact ceiling of this PASS

This PASS establishes coherence of the bounded reference implementation under the
included tests. It does not establish formation, constitutional Authority, human
or machine identity, subjective continuity, production security, Body status,
actual participation, external adoption, or a live field. The run mutates neither
Body 001 nor the supplied CONTINUITY and LIVE-STATE artifacts.
