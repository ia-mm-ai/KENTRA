# HTTP API

AvalancheGo exposes both legacy path routing and RPCChainVM header routing. The legacy base is:

```text
http://NODE:9650/ext/bc/BLOCKCHAIN_ID/
```

The equivalent header-routed request sends `Avalanche-Api-Route: BLOCKCHAIN_ID` to the node and leaves the LOCALITY route as the request path, for example `http://NODE:9650/status`. `REHEARSAL 001` checks that both forms return identical status, state, and receipt data on all three nodes.

## Read routes

| Method and route | Result |
|---|---|
| `GET /status` | VM/protocol target, accepted block height, revision, state commitment, active locus, pending count |
| `GET /genesis` | Parsed immutable genesis and its hashes |
| `GET /state` | Accepted public runtime state |
| `GET /blocks/{blockID}` | Known block and state commitment when verified |
| `GET /transitions/{transitionID}` | Pending or accepted canonical transition |
| `GET /receipts/{transitionID}` | Accepted effect and non-effects; `404` until accepted |

## Draft an unsigned transition

`POST /drafts` accepts strict JSON:

```json
{
  "operation": "BOUND",
  "actor_id": "YOUR-LOCALITY-ID",
  "actor_public_key": "PUBLIC_KEY_HEX",
  "locus_id": "LOCUS-001",
  "observed_at": 1789826400,
  "payload": {
    "locus_id": "LOCUS-001",
    "purpose_sha256": "64_LOWERCASE_HEX",
    "closure_condition_sha256": "64_LOWERCASE_HEX"
  }
}
```

The VM fills the schema, exact next revision, prior-state commitment, per-actor nonce, and operation effect. Drafting changes no state. Save the returned `unsigned` object and sign it offline with `--sign-unsigned`.

Drafts account for already queued valid transitions, so a client can build an ordered sequence without guessing the prospective revision or commitment. A signed transition can still become stale if consensus chooses a different branch before submission.

## Submit a signed transition

`POST /transitions` consumes the exact canonical transition bytes, not an envelope. A successful response is `202 Accepted` with `PENDING_CONSENSUS`. This is not an acceptance receipt.

```bash
curl --fail --silent --show-error \
  -H 'Content-Type: application/json' \
  --data-binary @transition.json \
  http://127.0.0.1:9650/ext/bc/BLOCKCHAIN_ID/transitions
```

The same submission using header routing is:

```bash
curl --fail --silent --show-error \
  -H 'Content-Type: application/json' \
  -H 'Avalanche-Api-Route: BLOCKCHAIN_ID' \
  --data-binary @transition.json \
  http://127.0.0.1:9650/transitions
```

Poll the receipt route by the returned 64-character transition ID. A receipt exists only after the containing block is accepted.

## Error discipline

Errors are JSON objects with an `error` string and an appropriate HTTP status. Submission rejects invalid signatures, stale revisions, stale commitments, wrong nonces, unauthorized operations, unmet lifecycle preconditions, duplicate identities, residue commitment/addressee mismatches, and non-canonical bytes before they enter the mempool.
