# Consensus operations

| Operation | Signer | Principal preconditions | Consensus effect | Explicit non-effect |
|---|---|---|---|---|
| `BOUND` | Host | No open locus; unused locus ID | Opens one temporary locus | Does not create participants or relation |
| `PRESENT_FORM` | Presenting actor | Open locus; exact LOCALITY Form; required medium capabilities and effect ceiling | Records current public presentation and binds a new key-derived actor | No formation, admission, entry, or authority transfer |
| `GATE_DISPOSITION` | Host | Current presentation; participant not entered | Sets `ADMIT`, `REFUSE`, `WITHHOLD`, or `HOLD` | `ADMIT` is not entry |
| `ENTER` | Presenting actor | Current matching presentation and current `ADMIT` | Marks actor present in the locus | Entry is not matter admission |
| `OBSERVE_CROSSING` | Host or present actor | Open locus; unique matter ID | Records content digest, media type, bounded claim, and observer | Crossing is not truth or admission |
| `MATTER_DISPOSITION` | Host or present actor | Matter has crossed | Sets only the signer's local posture | Cannot set another locality's posture |
| `RECORD_EMERGENCE` | Host | Contributors present; every contributor admitted every named matter item | Records field-local emergence | No automatic local uptake |
| `CORRECT` | Original actor | Target event exists and belongs to signer | Appends correction edge | Does not erase predecessor |
| `EXIT` | Present actor | Actor presently entered | Ends that actor's presence | Does not close or erase locus |
| `CLOSE` | Host | Addressed open locus | Closes locus and emits addressed residue | No automatic incorporation or erasure |
| `INCORPORATE_ADDRESSED_RESIDUE` | Receiving locality host | Unique, internally valid residue envelope addressed exactly to this locality | Records a local incorporation decision | Does not prove source-chain inclusion, mutate the source field, or cause another locality's uptake |

## Ordering invariants

- Revisions are global and strictly increment by one.
- Nonces are per operational actor and strictly increment by one.
- Every transition commits to the exact previous runtime state.
- Every block commits to the exact parent block.
- Duplicate transitions, locus IDs, matter IDs, emergence IDs, and residue incorporations are rejected at their relevant scope.
- Unknown JSON fields, trailing values, non-lowercase hexadecimal values, and non-canonical transition/block encodings are rejected.

## Current bounded choices

- One host Ed25519 authority is supported in genesis. Threshold and rotation semantics are deferred to an explicit versioned successor.
- One locus may be open at a time.
- State and event history are public. Private state must remain outside transaction payloads.
- The VM records commitments and attributed claims; it does not authenticate a human, prove source continuity, or infer external truth.
