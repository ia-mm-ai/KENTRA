# LOCALITY state machine

## State model

The accepted state is a deterministic JSON object committed by SHA-256. Every transition names:

- the next global revision;
- the exact previous state commitment;
- an operational actor ID and public key;
- that actor's next nonce;
- a locus, when the operation is locus-bound;
- an explicit effect;
- an operation-specific payload;
- an Ed25519 signature over the canonical unsigned object.

A block is valid only if its transitions apply sequentially to the parent block's post-state. Acceptance atomically persists the block, post-state, height index, raw transitions, and receipts.

## Identities and references

`actor_id` is a signing identity, not an ontological claim. The host actor is explicitly bound in genesis. Every new participant actor must equal:

```text
LOCALITY-ACTOR- + first 20 bytes of SHA-256(ed25519 public key), lowercase hex
```

The participant's readable locality reference is separately exposed in `PRESENT_FORM.payload.locality_reference`. Presenting it does not prove identity, truth, authority, formation, or admission.

## Locus lifecycle

```mermaid
stateDiagram-v2
    [*] --> Closed
    Closed --> Open: BOUND by host
    Open --> Open: present / gate / enter / relate
    Open --> Closed: CLOSE by host
    Closed --> Open: BOUND with unused locus ID
```

Only one locus may be open at a time. Closed loci remain in history. Locus IDs cannot be reused.

## Participant lifecycle

```mermaid
stateDiagram-v2
    [*] --> Presented: PRESENT_FORM
    Presented --> Presented: REFUSE / WITHHOLD / HOLD
    Presented --> Admitted: ADMIT
    Admitted --> Present: ENTER
    Present --> Exited: EXIT
    Present --> ClosedWithField: CLOSE
    Exited --> Presented: new PRESENT_FORM
    ClosedWithField --> Presented: new locus + PRESENT_FORM
```

The `Admitted` node is a gate posture, not presence. It becomes presence only through a separately signed `ENTER` transition by the participant.

## Matter and emergence

`OBSERVE_CROSSING` creates a public record that bytes identified by a digest crossed the locus. It does not establish that the bytes were received elsewhere, interpreted correctly, true, admitted, or incorporated.

Each present participant controls only its own matter posture. An emergence record can name contributors and matter only after every named contributor has explicitly set `ADMIT` for every named matter item. The resulting effect is `FIELD_LOCAL_RECORD_ONLY`; it creates no automatic uptake in any contributor's locality.

## Correction and residue

`CORRECT` can target only a transition attributed to the same actor. It appends a replacement commitment and reason while leaving the target event and raw transition intact.

`CLOSE` deterministically emits residue addressed to the locality reference in each entered participant's current presentation. The residue effect is `AVAILABLE_FOR_ADDRESSEE_DECISION_ONLY`. The receiving locality must later perform its own host-signed `INCORPORATE_ADDRESSED_RESIDUE`; closure alone cannot do that work.

Import recomputes both the residue envelope hash and domain-separated residue ID. The envelope's `addressed_to_locality_id` must exactly equal the receiving genesis locality ID. This verifies internal commitment integrity and addressee, but it is not a cross-chain inclusion proof; cryptographic source proof remains outside version 1.
