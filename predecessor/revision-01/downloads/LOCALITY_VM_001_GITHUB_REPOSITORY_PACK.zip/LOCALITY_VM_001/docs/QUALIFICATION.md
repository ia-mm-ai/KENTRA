# Qualification contract

The repository contains production-intent `LOCALITY_VM_001` source, but source presence is not deployment evidence. A commit is deployable only after its own qualification workflow passes. Evidence from the predecessor or an earlier binary does not transfer.

## Required automated gates

The `Qualify LOCALITY VM 001` GitHub workflow must pass on the exact commit to be released:

1. repository structure, JSON, shell, Python, manifest, and private-material checks;
2. Go unit and integration tests;
3. race detector;
4. `go vet`;
5. native Linux amd64 VM build;
6. exact AvalancheGo `v1.15.0` annotated-tag dereference to commit `70bd6d063b7343fd2cd8217200aaf77b57f19f68`;
7. reproducible application of `LOCALITY_SECURITY_OVERLAY_001` and its exact module-file digests;
8. zero reachable vulnerabilities reported by pinned `govulncheck@v1.7.0` for both the VM and overlaid AvalancheGo node;
9. three-validator disposable network bootstrap;
10. complete lifecycle execution;
11. equal accepted state on all three validators;
12. full-network restart replay;
13. one-validator stop, restart, and exact-state rejoin.

The workflow publishes public evidence only. Disposable locality authorities and validator credentials remain in a private temporary directory and are destroyed after the run.

The qualified compatibility identity is `v1.15.0+LOCALITY_SECURITY_OVERLAY_001`, not an unmodified `v1.15.0` node. The overlay is a bounded dependency-only delta whose input and output `go.mod`/`go.sum` digests are committed in `compat/AVALANCHEGO_SECURITY_OVERLAY_001.json`.

## Deployment gates not automated here

Before Mainnet formation, the operator must additionally complete:

- independent Go, Avalanche consensus, and cryptographic review;
- Fuji rehearsal with persisted validator credentials;
- restoration of those credentials onto a clean host while preserving the exact NodeID;
- partition, conflicting-block, validator replacement, resource-limit, API-abuse, and state-growth tests;
- network exposure, observability, backup, incident response, and upgrade procedures;
- a deliberate decision about single-key host authority recovery or a versioned threshold/rotation successor.

## Release meaning

Version `1.0.0` is the protocol and artifact identity. It does not certify any particular deployment, operator, validator, or chain. A GitHub release is admissible only when the release workflow re-runs the automated gates on that exact tag.
