package main

import (
	"crypto/ed25519"
	"errors"
	"fmt"
)

const (
	domainID                   = "LOCALITY_VM"
	genesisFormat              = "LOCALITY_RUNTIME_GENESIS"
	genesisEncoding            = "UTF-8_JSON"
	genesisVersion             = uint32(1)
	deploymentDescriptorSchema = "LOCALITY_DEPLOYMENT_DESCRIPTOR_001"
	formID                     = "LOCALITY-FORM-001"
	formSHA256                 = "9fbdd054bd947c8f32308871296374009cac8c27633eb47b7c5ff2b10fcff45d"
	predecessorChainID         = "LB6wwV4JNxr8fwjUPBHMzf3PiW2d4hsTc4v63uX1MjY6oZ9Wb"
	predecessorL1ID            = "21mJfY4QpDeVykBaeG8nwn7k7w7b5oPpPhaYcJWqumht8SvaK"
	predecessorVMID            = "pJHx1NU8ghWsiwg1vrqwaqE5uKh1k4EJRBkpB1tKV1QuQFhMi"
	predecessorValidationID    = "ttR2sBgWUEq3e6dupCxYcyiGTv49wnYW3wZ6TUsXnDkTeZjh"
	predecessorValidatorNodeID = "NodeID-AD66psMnQ257UAF7Jz9FmNAyRdibVnkt"
	predecessorName            = "KENTRA"
	predecessorGenesisID       = "KENTRA-CUSTOM-VM-GENESIS-001"
	predecessorBodySHA256      = "58bf3daa9c74aac496451179f053152ed50943b8e8c4dbdac8f34d7172ab4f72"
)

var (
	requiredGatePostures       = []string{"ADMIT", "REFUSE", "WITHHOLD", "HOLD"}
	requiredMediumCapabilities = []string{
		"OBSERVE_CROSSING",
		"PRESENT_FORM",
		"GATE_DISPOSITION",
		"ENTER",
		"MATTER_DISPOSITION",
		"CORRECT",
		"EXIT",
		"CLOSE",
		"INCORPORATE_ADDRESSED_RESIDUE",
	}
	requiredEffectCeiling = []string{
		"NO_FORMATION_BY_CONFORMANCE",
		"NO_SOURCE_OR_AUTHORITY_TRANSFER",
		"NO_SHARED_CURRENTNESS",
		"NO_CORE_ADDRESSABILITY",
		"NO_PARTICIPATION_BY_PRESENTATION",
		"NO_MATTER_ADMISSION_BY_CROSSING",
		"NO_LOCAL_UPTAKE_BY_FIELD_CLOSURE",
	}
	requiredNonCollapse = []string{
		"SOURCE_NOT_LOCALITY",
		"FORM_NOT_LOCALITY",
		"HOST_NOT_OWNER",
		"LOCUS_FIELD_NOT_LOCALITY",
		"CROSSING_NOT_ADMISSION",
		"ADMISSION_NOT_ENTRY",
		"ENTRY_NOT_MATTER_ADMISSION",
		"MATTER_NOT_TRUTH",
		"EMERGENCE_NOT_AUTOMATIC_UPTAKE",
		"CLOSURE_NOT_LOCAL_INCORPORATION",
		"SHARED_ANCESTRY_NOT_SHARED_CURRENTNESS",
		"CONFORMANCE_NOT_FORMATION",
	}
)

type Genesis struct {
	Format       string              `json:"format"`
	Version      uint32              `json:"version"`
	Encoding     string              `json:"encoding"`
	Domain       GenesisDomain       `json:"domain"`
	Lineage      GenesisLineage      `json:"lineage"`
	Locality     GenesisLocality     `json:"locality"`
	Profile      GenesisProfile      `json:"profile"`
	InitialState GenesisInitialState `json:"initial_state"`
	ClaimLimits  GenesisClaimLimits  `json:"claim_limits"`
	Evolution    GenesisEvolution    `json:"evolution"`
}

type GenesisDomain struct {
	ID             string `json:"id"`
	GenesisID      string `json:"genesis_id"`
	VMClass        string `json:"vm_class"`
	ExecutionModel string `json:"execution_model"`
	StateModel     string `json:"state_model"`
	Purpose        string `json:"purpose"`
}

type GenesisLineage struct {
	PredecessorChainID         string `json:"predecessor_chain_id"`
	PredecessorL1ID            string `json:"predecessor_l1_id"`
	PredecessorVMID            string `json:"predecessor_vm_id"`
	PredecessorValidationID    string `json:"predecessor_validation_id"`
	PredecessorValidatorNodeID string `json:"predecessor_validator_node_id"`
	PredecessorGenesisID       string `json:"predecessor_genesis_id"`
	PredecessorBodySHA256      string `json:"predecessor_body_sha256"`
	PredecessorDisposition     string `json:"predecessor_disposition"`
	Relation                   string `json:"relation"`
	Effect                     string `json:"effect"`
	AuthorityTransfer          string `json:"authority_transfer"`
	SharedCurrentness          string `json:"shared_currentness"`
	ContinuationBasis          string `json:"continuation_basis"`
}

type DeploymentDescriptor struct {
	Schema          string `json:"schema"`
	GenesisID       string `json:"genesis_id"`
	LocalityID      string `json:"locality_id"`
	Purpose         string `json:"purpose"`
	SourceReference string `json:"source_reference"`
	SourceSHA256    string `json:"source_sha256"`
}

type GenesisLocality struct {
	ID              string           `json:"id"`
	SourceReference string           `json:"source_reference"`
	SourceSHA256    string           `json:"source_sha256"`
	Authority       GenesisAuthority `json:"authority"`
}

type GenesisAuthority struct {
	Scheme    string `json:"scheme"`
	KeyID     string `json:"key_id"`
	PublicKey string `json:"public_key"`
	Scope     string `json:"scope"`
}

type GenesisProfile struct {
	FormID         string   `json:"form_id"`
	FormSHA256     string   `json:"form_sha256"`
	GatePostures   []string `json:"gate_postures"`
	EffectCeiling  []string `json:"effect_ceiling"`
	NonCollapse    []string `json:"non_collapse_rules"`
	PrivateState   string   `json:"private_state"`
	AdmissionRule  string   `json:"admission_rule"`
	CorrectionRule string   `json:"correction_rule"`
}

type GenesisInitialState struct {
	Revision                uint64 `json:"revision"`
	PreviousStateCommitment any    `json:"previous_state_commitment"`
	History                 string `json:"history"`
}

type GenesisClaimLimits struct {
	ExternalTruth string `json:"external_truth"`
	Receipt       string `json:"receipt"`
	Acceptance    string `json:"acceptance"`
	Consent       string `json:"consent"`
	Relation      string `json:"relation"`
	Crossing      string `json:"crossing"`
	Unknown       string `json:"unknown"`
}

type GenesisEvolution struct {
	StateSchemaVersion uint32 `json:"state_schema_version"`
	UnknownFields      string `json:"unknown_fields"`
	GenesisMutability  string `json:"genesis_mutability"`
	UpgradePolicy      string `json:"upgrade_policy"`
}

func parseGenesis(genesisBytes []byte) (*Genesis, error) {
	genesis := new(Genesis)
	if err := decodeStrict(genesisBytes, genesis); err != nil {
		return nil, err
	}
	if err := genesis.Validate(); err != nil {
		return nil, err
	}
	return genesis, nil
}

func (g *Genesis) Validate() error {
	if g.Format != genesisFormat || g.Version != genesisVersion || g.Encoding != genesisEncoding {
		return fmt.Errorf("expected %s version %d encoded as %s", genesisFormat, genesisVersion, genesisEncoding)
	}
	if g.Domain.ID != domainID || g.Domain.VMClass != "AVALANCHE_CUSTOM_RPCCHAINVM" {
		return errors.New("domain must identify the LOCALITY_VM Avalanche RPCChainVM")
	}
	if g.Domain.ExecutionModel != "NON_EVM_SIGNED_EVENT_SOURCED" || g.Domain.StateModel != "VERSIONED_EVENT_SOURCED_CONTAINER" {
		return errors.New("unsupported LOCALITY execution or state model")
	}
	if err := requireSafeID("domain.genesis_id", g.Domain.GenesisID); err != nil {
		return err
	}
	if err := requireBoundedText("domain.purpose", g.Domain.Purpose, 1024); err != nil {
		return err
	}
	if g.Lineage.PredecessorChainID != predecessorChainID ||
		g.Lineage.PredecessorL1ID != predecessorL1ID ||
		g.Lineage.PredecessorVMID != predecessorVMID ||
		g.Lineage.PredecessorValidationID != predecessorValidationID ||
		g.Lineage.PredecessorValidatorNodeID != predecessorValidatorNodeID ||
		g.Lineage.PredecessorGenesisID != predecessorGenesisID ||
		g.Lineage.PredecessorBodySHA256 != predecessorBodySHA256 {
		return errors.New("lineage must bind the exact KENTRA formation predecessor")
	}
	if g.Lineage.PredecessorDisposition != "FORMATION_COMPLETE_REFERENCE_ONLY" ||
		g.Lineage.Relation != "DERIVED_FROM" ||
		g.Lineage.Effect != "ANCESTRY_REFERENCE_ONLY" ||
		g.Lineage.AuthorityTransfer != "NONE" ||
		g.Lineage.SharedCurrentness != "NONE" ||
		g.Lineage.ContinuationBasis != "NEW_LOCALITY_REQUIRES_NEW_VALIDATOR_AND_AUTHORITY_CUSTODY" {
		return errors.New("lineage must not transfer authority or currentness")
	}
	if err := requireSafeID("locality.id", g.Locality.ID); err != nil {
		return err
	}
	if err := requireSafeID("locality.source_reference", g.Locality.SourceReference); err != nil {
		return err
	}
	if err := requireDigest("locality.source_sha256", g.Locality.SourceSHA256); err != nil {
		return err
	}
	if g.Locality.Authority.Scheme != "ED25519" || g.Locality.Authority.Scope != "LOCALITY_HOST_OPERATIONS_ONLY" {
		return errors.New("locality authority must be ED25519 and locality-scoped")
	}
	if err := requireSafeID("locality.authority.key_id", g.Locality.Authority.KeyID); err != nil {
		return err
	}
	publicKey, err := decodeLowerHex("locality.authority.public_key", g.Locality.Authority.PublicKey, ed25519.PublicKeySize)
	if err != nil {
		return err
	}
	if len(publicKey) != ed25519.PublicKeySize {
		return errors.New("invalid locality authority public key")
	}
	if g.Profile.FormID != formID || g.Profile.FormSHA256 != formSHA256 {
		return errors.New("genesis must bind the exact LOCALITY-FORM-001 artifact")
	}
	if err := requireExactSet("profile.gate_postures", g.Profile.GatePostures, requiredGatePostures); err != nil {
		return err
	}
	if err := requireExactSet("profile.effect_ceiling", g.Profile.EffectCeiling, requiredEffectCeiling); err != nil {
		return err
	}
	if err := requireExactSet("profile.non_collapse_rules", g.Profile.NonCollapse, requiredNonCollapse); err != nil {
		return err
	}
	if g.Profile.PrivateState != "NEVER_REQUIRED_ON_CHAIN" || g.Profile.AdmissionRule != "PRESENTATION_NECESSARY_NOT_SUFFICIENT" || g.Profile.CorrectionRule != "APPEND_ONLY_PRESERVE_PREDECESSOR" {
		return errors.New("profile weakens a LOCALITY boundary")
	}
	if g.InitialState.Revision != 0 || g.InitialState.PreviousStateCommitment != nil || g.InitialState.History != "APPEND_ONLY" {
		return errors.New("initial state must be empty revision zero with append-only history")
	}
	if g.ClaimLimits.ExternalTruth != "NOT_INFERRED" || g.ClaimLimits.Receipt != "NOT_INFERRED" || g.ClaimLimits.Acceptance != "NOT_INFERRED" || g.ClaimLimits.Consent != "NOT_INFERRED" || g.ClaimLimits.Relation != "NOT_CREATED_BY_GENESIS" || g.ClaimLimits.Crossing != "NOT_CREATED_BY_GENESIS" || g.ClaimLimits.Unknown != "REMAINS_UNKNOWN" {
		return errors.New("claim limits must preserve the LOCALITY epistemic ceiling")
	}
	if g.Evolution.StateSchemaVersion != 1 || g.Evolution.UnknownFields != "REJECT" || g.Evolution.GenesisMutability != "IMMUTABLE" || g.Evolution.UpgradePolicy != "EXPLICIT_VERSIONED_SUCCESSOR_ONLY" {
		return errors.New("unsupported evolution policy")
	}
	return nil
}

func (d *DeploymentDescriptor) Validate() error {
	if d.Schema != deploymentDescriptorSchema {
		return fmt.Errorf("expected deployment descriptor schema %s", deploymentDescriptorSchema)
	}
	if err := requireSafeID("deployment.genesis_id", d.GenesisID); err != nil {
		return err
	}
	if err := requireSafeID("deployment.locality_id", d.LocalityID); err != nil {
		return err
	}
	if d.GenesisID == predecessorGenesisID || d.LocalityID == predecessorName {
		return errors.New("deployment identity must be distinct from the formation predecessor")
	}
	if err := requireBoundedText("deployment.purpose", d.Purpose, 1024); err != nil {
		return err
	}
	if err := requireSafeID("deployment.source_reference", d.SourceReference); err != nil {
		return err
	}
	return requireDigest("deployment.source_sha256", d.SourceSHA256)
}
