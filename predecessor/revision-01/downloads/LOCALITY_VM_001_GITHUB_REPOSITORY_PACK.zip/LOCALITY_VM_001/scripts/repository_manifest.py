#!/usr/bin/env python3
"""Create or verify the deterministic public repository checksum manifest."""

from __future__ import annotations

import argparse
import hashlib
import pathlib
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST.sha256"
EXCLUDED_PARTS = {".git", "build", "__pycache__", "runs", "evidence"}


def included_files() -> list[pathlib.Path]:
    files: list[pathlib.Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == MANIFEST:
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_PARTS for part in relative.parts):
            continue
        if relative.parts[:1] == ("artifacts",) and relative.name != ".gitkeep":
            continue
        files.append(path)
    return sorted(files, key=lambda path: path.relative_to(ROOT).as_posix())


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def render() -> str:
    return "".join(
        f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}\n"
        for path in included_files()
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.write == args.check:
        parser.error("select exactly one of --write or --check")
    expected = render()
    if args.write:
        MANIFEST.write_text(expected, encoding="utf-8")
        print(f"wrote {MANIFEST}")
        return 0
    try:
        observed = MANIFEST.read_text(encoding="utf-8")
    except FileNotFoundError:
        print("MANIFEST.sha256 is missing", file=sys.stderr)
        return 1
    if observed != expected:
        print("MANIFEST.sha256 does not match repository contents", file=sys.stderr)
        return 1
    print("repository checksum manifest: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
