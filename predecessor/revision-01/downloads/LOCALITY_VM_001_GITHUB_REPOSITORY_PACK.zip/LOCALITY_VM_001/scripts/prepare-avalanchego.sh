#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: $0 OUTPUT_SOURCE_DIRECTORY" >&2
  exit 2
fi

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
output_source="$1"
go_binary="${GO_BINARY:-go}"
overlay="${root_dir}/compat/AVALANCHEGO_SECURITY_OVERLAY_001.json"

for command_name in git jq sha256sum; do
  if ! command -v "${command_name}" >/dev/null 2>&1; then
    echo "required command is unavailable: ${command_name}" >&2
    exit 1
  fi
done
if ! go_binary="$(command -v "${go_binary}")"; then
  echo "Go compiler is unavailable" >&2
  exit 1
fi
if [[ "$("${go_binary}" env GOVERSION)" != "go1.25.13" ]]; then
  echo "AvalancheGo preparation requires exact Go 1.25.13" >&2
  exit 1
fi
export PATH="$(dirname "${go_binary}"):${PATH}"
if [[ -e "${output_source}" ]]; then
  echo "refusing to overwrite AvalancheGo source path: ${output_source}" >&2
  exit 1
fi

repository="$(jq -r '.base.repository' "${overlay}")"
tag="$(jq -r '.base.tag' "${overlay}")"
expected_tag_object="$(jq -r '.base.tag_object' "${overlay}")"
expected_commit="$(jq -r '.base.peeled_commit' "${overlay}")"

git init --quiet "${output_source}"
git -C "${output_source}" remote add origin "${repository}"
git -C "${output_source}" fetch --quiet --depth=1 origin "refs/tags/${tag}:refs/tags/${tag}"
observed_tag_object="$(git -C "${output_source}" rev-parse "refs/tags/${tag}")"
observed_commit="$(git -C "${output_source}" rev-parse "refs/tags/${tag}^{commit}")"
if [[ "${observed_tag_object}" != "${expected_tag_object}" || "${observed_commit}" != "${expected_commit}" ]]; then
  echo "AvalancheGo tag identity mismatch" >&2
  exit 1
fi
git -C "${output_source}" checkout --quiet --detach "${observed_commit}"

for filename in go.mod go.sum; do
  expected="$(jq -r ".base.${filename//./_}_sha256" "${overlay}")"
  observed="$(sha256sum "${output_source}/${filename}" | awk '{print $1}')"
  if [[ "${observed}" != "${expected}" ]]; then
    echo "AvalancheGo base ${filename} digest mismatch" >&2
    exit 1
  fi
done

(
  cd "${output_source}"
  GOTOOLCHAIN=local GOWORK=off "${go_binary}" get google.golang.org/grpc@v1.83.2
  GOTOOLCHAIN=local GOWORK=off "${go_binary}" mod tidy
)

for filename in go.mod go.sum; do
  expected="$(jq -r ".result.${filename//./_}_sha256" "${overlay}")"
  observed="$(sha256sum "${output_source}/${filename}" | awk '{print $1}')"
  if [[ "${observed}" != "${expected}" ]]; then
    echo "AvalancheGo overlaid ${filename} digest mismatch" >&2
    exit 1
  fi
done

while IFS=$'\t' read -r module expected_version; do
  observed_version="$(cd "${output_source}" && GOTOOLCHAIN=local GOWORK=off "${go_binary}" list -m -f '{{.Version}}' "${module}")"
  if [[ "${observed_version}" != "${expected_version}" ]]; then
    echo "AvalancheGo overlay module mismatch for ${module}: ${observed_version}" >&2
    exit 1
  fi
done < <(jq -r '.resolved_modules | to_entries[] | [.key, .value] | @tsv' "${overlay}")

changed_files="$(git -C "${output_source}" diff --name-only | sort)"
if [[ "${changed_files}" != $'go.mod\ngo.sum' ]]; then
  echo "security overlay changed unexpected AvalancheGo files:" >&2
  echo "${changed_files}" >&2
  exit 1
fi

echo "prepared AvalancheGo ${tag} (${observed_commit}) + LOCALITY_SECURITY_OVERLAY_001"
echo "source: ${output_source}"
