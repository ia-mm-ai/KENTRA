#!/usr/bin/env python3
"""Fail closed on repository drift before Go compilation or release."""

from __future__ import annotations

import ast
import hashlib
import json
import pathlib
import re
import subprocess
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
EXPECTED_VM_ID = "4qSsv1gPp2ctpYFTt4Nm9YQqSEggVzauPw3kRGmziwVqLU1PP"
EXPECTED_FORM_SHA = "9fbdd054bd947c8f32308871296374009cac8c27633eb47b7c5ff2b10fcff45d"
EXPECTED_AVALANCHEGO_COMMIT = "70bd6d063b7343fd2cd8217200aaf77b57f19f68"
STALE_VALUES = {
    "5a6a51ce529082df807006bdc8bb9a2d4f5b05d9d023ed5e51264d0111e64f24",
    "LOCALITY-SUCCESSOR-001",
    "locality-vm/0.1.1",
    "1.25.10",
}


def fail(message: str) -> None:
    raise RuntimeError(message)


def read_json(relative: str) -> object:
    with (ROOT / relative).open("r", encoding="utf-8") as source:
        return json.load(source)


def sha256(relative: str) -> str:
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


def check_required_files() -> None:
    required = {
        ".github/workflows/qualify.yml",
        ".github/workflows/release.yml",
        "LINEAGE.md",
        "RELEASE_MANIFEST.json",
        "examples/DEPLOYMENT_DESCRIPTOR.example.json",
        "compat/AVALANCHEGO_SECURITY_OVERLAY_001.json",
        "genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_001.json",
        "lineage/KENTRA_PREDECESSOR.json",
        "profile/LOCALITY_FORM_001.json",
        "scripts/build-avalanchego.sh",
        "scripts/preflight-node.sh",
        "scripts/prepare-avalanchego.sh",
        "scripts/vulnerability-scan.sh",
    }
    missing = sorted(path for path in required if not (ROOT / path).is_file())
    if missing:
        fail(f"required repository files are missing: {missing}")


def check_json_documents() -> None:
    for path in sorted(ROOT.rglob("*.json")):
        if any(part in {".git", "build", "runs", "evidence"} for part in path.parts):
            continue
        with path.open("r", encoding="utf-8") as source:
            json.load(source)


def check_release_manifest() -> None:
    manifest = read_json("RELEASE_MANIFEST.json")
    release = manifest["release"]
    compatibility = manifest["compatibility"]
    if release != {
        "protocol": "LOCALITY_VM_001",
        "version": "1.0.0",
        "binary_name": "locality-vm",
        "go_module": "locality.vm/runtime",
        "vm_id_domain": "LOCALITY_VM_001",
        "vm_id": EXPECTED_VM_ID,
        "status": "PRODUCTION_INTENT_REQUIRES_EXACT_COMMIT_QUALIFICATION",
    }:
        fail("release identity differs from LOCALITY_VM_001 v1.0.0")
    if compatibility["avalanchego_tag"] != "v1.15.0":
        fail("AvalancheGo tag is not v1.15.0")
    if compatibility["avalanchego_peeled_commit"] != EXPECTED_AVALANCHEGO_COMMIT:
        fail("AvalancheGo peeled commit changed")
    if compatibility["rpcchainvm_protocol"] != 46 or compatibility["go"] != "1.25.13":
        fail("toolchain compatibility target changed")
    if compatibility["avalanchego_profile"] != "v1.15.0+LOCALITY_SECURITY_OVERLAY_001":
        fail("AvalancheGo security profile changed")
    if compatibility["vulnerability_scanner"] != "golang.org/x/vuln/cmd/govulncheck@v1.7.0":
        fail("vulnerability scanner changed")
    for artifact in manifest["bound_artifacts"].values():
        if sha256(artifact["path"]) != artifact["sha256"]:
            fail(f"bound artifact digest mismatch: {artifact['path']}")


def check_genesis_boundary() -> None:
    genesis = read_json("genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_001.json")
    deployment_fields = (
        genesis["domain"]["genesis_id"],
        genesis["domain"]["purpose"],
        genesis["locality"]["id"],
        genesis["locality"]["source_reference"],
        genesis["locality"]["source_sha256"],
    )
    if any(deployment_fields):
        fail("genesis template embeds a deployment-specific identity or source")
    predecessor = read_json("lineage/KENTRA_PREDECESSOR.json")
    avalanche = predecessor["avalanche_mainnet"]
    lineage = genesis["lineage"]
    expected = {
        "predecessor_chain_id": avalanche["blockchain_id"],
        "predecessor_l1_id": avalanche["l1_id"],
        "predecessor_vm_id": avalanche["vm_id"],
        "predecessor_validation_id": avalanche["validation_id"],
        "predecessor_validator_node_id": avalanche["validator_node_id"],
        "predecessor_genesis_id": predecessor["genesis_id"],
        "predecessor_body_sha256": predecessor["body_sha256"],
        "predecessor_disposition": predecessor["disposition"],
        "relation": predecessor["relation_to_successor"],
        "effect": predecessor["effect"],
        "authority_transfer": predecessor["authority_transfer"],
        "shared_currentness": predecessor["shared_currentness"],
        "continuation_basis": predecessor["continuation_basis"],
    }
    if lineage != expected:
        fail("genesis lineage and predecessor record disagree")
    if genesis["profile"]["form_sha256"] != EXPECTED_FORM_SHA:
        fail("genesis does not bind the release form")


def check_source_identity() -> None:
    main = (ROOT / "main.go").read_text(encoding="utf-8")
    genesis = (ROOT / "genesis.go").read_text(encoding="utf-8")
    if not re.search(r'\bvmVersion\s*=\s*"locality-vm/1\.0\.0"', main):
        fail("main.go version contract changed")
    if not re.search(r'\bvmIDDomain\s*=\s*"LOCALITY_VM_001"', main):
        fail("main.go VM ID domain changed")
    if not re.search(
        r'\bavalancheGoProfile\s*=\s*"v1\.15\.0\+LOCALITY_SECURITY_OVERLAY_001"',
        main,
    ):
        fail("main.go AvalancheGo security profile changed")
    if EXPECTED_FORM_SHA not in genesis:
        fail("genesis.go form commitment changed")


def check_no_stale_or_private_material() -> None:
    forbidden_names = {"staker.key", "signer.key", "locality-authority.private.json"}
    textual_suffixes = {".go", ".md", ".json", ".py", ".sh", ".yml", ".yaml", ".mod"}
    for path in ROOT.rglob("*"):
        if not path.is_file() or any(
            part in {".git", "artifacts", "build", "__pycache__", "runs", "evidence"}
            for part in path.parts
        ):
            continue
        if path.name in forbidden_names or path.name.endswith(".private.json"):
            fail(f"private credential material must not be committed: {path.relative_to(ROOT)}")
        if path.suffix not in textual_suffixes:
            continue
        text = path.read_text(encoding="utf-8")
        if path.resolve() != pathlib.Path(__file__).resolve():
            for stale in STALE_VALUES:
                if stale in text:
                    fail(f"stale release value {stale!r} in {path.relative_to(ROOT)}")
        if "\r" in text:
            fail(f"CRLF line ending in {path.relative_to(ROOT)}")
        if re.search(r"[ \t]+$", text, flags=re.MULTILINE):
            fail(f"trailing whitespace in {path.relative_to(ROOT)}")
    active_paths = (
        list(ROOT.glob("*.go"))
        + list((ROOT / "scripts").glob("*.sh"))
        + list((ROOT / "rehearsal").glob("*.go"))
        + [ROOT / "rehearsal/run_lifecycle.py"]
    )
    for path in active_paths:
        if path.is_file() and path.name != "genesis.go" and "KENTRA" in path.read_text(encoding="utf-8"):
            fail(f"active protocol code contains predecessor locality naming: {path.relative_to(ROOT)}")


def check_python_syntax() -> None:
    for path in sorted(ROOT.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def main() -> int:
    try:
        check_required_files()
        check_json_documents()
        check_release_manifest()
        check_genesis_boundary()
        check_source_identity()
        check_no_stale_or_private_material()
        check_python_syntax()
        subprocess.run(
            [sys.executable, str(ROOT / "scripts/repository_manifest.py"), "--check"],
            check=True,
        )
    except (KeyError, TypeError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"repository verification failed: {error}", file=sys.stderr)
        return 1
    print("LOCALITY VM repository verification: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
