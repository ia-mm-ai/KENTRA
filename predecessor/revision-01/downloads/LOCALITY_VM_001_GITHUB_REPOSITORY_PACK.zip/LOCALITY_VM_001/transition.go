package main

import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/ava-labs/avalanchego/ids"
)

const transitionSchema = "LOCALITY_TRANSITION_001"

const (
	opBound              = "BOUND"
	opPresentForm        = "PRESENT_FORM"
	opGateDisposition    = "GATE_DISPOSITION"
	opEnter              = "ENTER"
	opObserveCrossing    = "OBSERVE_CROSSING"
	opMatterDisposition  = "MATTER_DISPOSITION"
	opRecordEmergence    = "RECORD_EMERGENCE"
	opCorrect            = "CORRECT"
	opExit               = "EXIT"
	opClose              = "CLOSE"
	opIncorporateResidue = "INCORPORATE_ADDRESSED_RESIDUE"
)

var operationEffects = map[string]string{
	opBound:              "OPENS_TEMPORARY_LOCUS_ONLY",
	opPresentForm:        "ELIGIBILITY_TO_GATE_ONLY",
	opGateDisposition:    "SETS_GATE_POSTURE_ONLY",
	opEnter:              "ENTERS_CURRENT_LOCUS_ONLY",
	opObserveCrossing:    "RECORDS_CROSSING_ONLY",
	opMatterDisposition:  "SETS_ACTOR_LOCAL_MATTER_POSTURE_ONLY",
	opRecordEmergence:    "RECORDS_FIELD_LOCAL_EMERGENCE_ONLY",
	opCorrect:            "APPENDS_CORRECTION_ONLY",
	opExit:               "EXITS_CURRENT_LOCUS_ONLY",
	opClose:              "CLOSES_LOCUS_AND_ADDRESSES_RESIDUE_ONLY",
	opIncorporateResidue: "INCORPORATES_ADDRESSED_RESIDUE_LOCALLY_ONLY",
}

type UnsignedTransition struct {
	Schema                  string          `json:"schema"`
	Operation               string          `json:"operation"`
	Revision                uint64          `json:"revision"`
	PreviousStateCommitment string          `json:"previous_state_commitment"`
	ActorID                 string          `json:"actor_id"`
	ActorPublicKey          string          `json:"actor_public_key"`
	Nonce                   uint64          `json:"nonce"`
	LocusID                 string          `json:"locus_id"`
	ObservedAt              int64           `json:"observed_at"`
	Effect                  string          `json:"effect"`
	Payload                 json.RawMessage `json:"payload"`
}

type Transition struct {
	Unsigned  UnsignedTransition `json:"unsigned"`
	Signature string             `json:"signature"`
}

type BoundPayload struct {
	LocusID                string `json:"locus_id"`
	PurposeSHA256          string `json:"purpose_sha256"`
	ClosureConditionSHA256 string `json:"closure_condition_sha256"`
}

type PresentFormPayload struct {
	LocalityReference  string   `json:"locality_reference"`
	SourceReference    string   `json:"source_reference"`
	SourceSHA256       string   `json:"source_sha256"`
	NucleusVersion     string   `json:"nucleus_version"`
	NucleusSHA256      string   `json:"nucleus_sha256"`
	FormID             string   `json:"form_id"`
	FormSHA256         string   `json:"form_sha256"`
	StateCommitment    string   `json:"state_commitment"`
	MediumCapabilities []string `json:"medium_capabilities"`
	EffectCeiling      []string `json:"effect_ceiling"`
}

type GateDispositionPayload struct {
	ParticipantID  string `json:"participant_id"`
	PresentationID string `json:"presentation_id"`
	Disposition    string `json:"disposition"`
	ReasonSHA256   string `json:"reason_sha256"`
}

type EnterPayload struct {
	PresentationID string `json:"presentation_id"`
}

type ObserveCrossingPayload struct {
	MatterID      string `json:"matter_id"`
	ContentSHA256 string `json:"content_sha256"`
	MediaType     string `json:"media_type"`
	Claim         string `json:"claim"`
}

type MatterDispositionPayload struct {
	MatterID     string `json:"matter_id"`
	Disposition  string `json:"disposition"`
	ReasonSHA256 string `json:"reason_sha256"`
}

type RecordEmergencePayload struct {
	EmergenceID       string   `json:"emergence_id"`
	ContributorIDs    []string `json:"contributor_ids"`
	MatterIDs         []string `json:"matter_ids"`
	Kind              string   `json:"kind"`
	DescriptionSHA256 string   `json:"description_sha256"`
}

type CorrectPayload struct {
	TargetTransitionID    string `json:"target_transition_id"`
	ReplacementCommitment string `json:"replacement_commitment"`
	ReasonSHA256          string `json:"reason_sha256"`
}

type ExitPayload struct {
	ReasonSHA256 string `json:"reason_sha256"`
}

type ClosePayload struct {
	ClosureBasisSHA256 string `json:"closure_basis_sha256"`
}

type IncorporateResiduePayload struct {
	ResidueID             string `json:"residue_id"`
	ResidueSHA256         string `json:"residue_sha256"`
	Schema                string `json:"schema"`
	AddressedToLocalityID string `json:"addressed_to_locality_id"`
	SourceLocalityID      string `json:"source_locality_id"`
	SourceLocusID         string `json:"source_locus_id"`
	SourceStateCommitment string `json:"source_state_commitment"`
	ClosureTransitionID   string `json:"closure_transition_id"`
	Effect                string `json:"effect"`
}

func parseTransition(transitionBytes []byte) (*Transition, ids.ID, error) {
	transition := new(Transition)
	if err := decodeCanonical(transitionBytes, transition); err != nil {
		return nil, ids.Empty, err
	}
	if err := transition.ValidateSyntax(); err != nil {
		return nil, ids.Empty, err
	}
	digest := sha256.Sum256(transitionBytes)
	return transition, ids.ID(digest), nil
}

func (t *Transition) Bytes() ([]byte, error) {
	return json.Marshal(t)
}

func (t *Transition) ID() (ids.ID, error) {
	bytes, err := t.Bytes()
	if err != nil {
		return ids.Empty, err
	}
	return ids.ID(sha256.Sum256(bytes)), nil
}

func (t *Transition) SigningBytes() ([]byte, error) {
	return json.Marshal(&t.Unsigned)
}

func (t *Transition) VerifySignature() error {
	publicKey, err := decodeLowerHex("actor_public_key", t.Unsigned.ActorPublicKey, ed25519.PublicKeySize)
	if err != nil {
		return err
	}
	signature, err := decodeLowerHex("signature", t.Signature, ed25519.SignatureSize)
	if err != nil {
		return err
	}
	signingBytes, err := t.SigningBytes()
	if err != nil {
		return err
	}
	if !ed25519.Verify(publicKey, signingBytes, signature) {
		return errors.New("invalid Ed25519 transition signature")
	}
	return nil
}

func (t *Transition) ValidateSyntax() error {
	u := &t.Unsigned
	if u.Schema != transitionSchema {
		return fmt.Errorf("unsupported transition schema %q", u.Schema)
	}
	expectedEffect, exists := operationEffects[u.Operation]
	if !exists {
		return fmt.Errorf("unsupported operation %q", u.Operation)
	}
	if u.Effect != expectedEffect {
		return fmt.Errorf("operation %s requires explicit effect %s", u.Operation, expectedEffect)
	}
	if u.Revision == 0 {
		return errors.New("transition revision must be greater than zero")
	}
	if err := requireDigest("previous_state_commitment", u.PreviousStateCommitment); err != nil {
		return err
	}
	if err := requireSafeID("actor_id", u.ActorID); err != nil {
		return err
	}
	if _, err := decodeLowerHex("actor_public_key", u.ActorPublicKey, ed25519.PublicKeySize); err != nil {
		return err
	}
	if u.LocusID != "" {
		if err := requireSafeID("locus_id", u.LocusID); err != nil {
			return err
		}
	}
	if u.ObservedAt < 0 {
		return errors.New("observed_at cannot be negative")
	}
	canonicalPayload, err := validateAndCanonicalizePayload(u.Operation, u.Payload)
	if err != nil {
		return err
	}
	if !bytes.Equal(canonicalPayload, u.Payload) {
		return errors.New("transition payload is not canonical")
	}
	return t.VerifySignature()
}

func validateAndCanonicalizePayload(operation string, raw json.RawMessage) ([]byte, error) {
	switch operation {
	case opBound:
		p, err := decodePayload[BoundPayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.locus_id", p.LocusID); err != nil {
			return nil, err
		}
		if err := requireDigest("payload.purpose_sha256", p.PurposeSHA256); err != nil {
			return nil, err
		}
		if err := requireDigest("payload.closure_condition_sha256", p.ClosureConditionSHA256); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	case opPresentForm:
		p, err := decodePayload[PresentFormPayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.locality_reference", p.LocalityReference); err != nil {
			return nil, err
		}
		if p.SourceReference == "" || p.NucleusVersion == "" {
			return nil, errors.New("presentation requires locality_reference, source_reference, and nucleus_version")
		}
		for name, value := range map[string]string{
			"source_sha256": p.SourceSHA256, "nucleus_sha256": p.NucleusSHA256,
			"form_sha256": p.FormSHA256, "state_commitment": p.StateCommitment,
		} {
			if err := requireDigest("payload."+name, value); err != nil {
				return nil, err
			}
		}
		if p.FormID != formID || p.FormSHA256 != formSHA256 {
			return nil, errors.New("presentation does not expose exact LOCALITY-FORM-001")
		}
		if err := requireUniqueNonEmpty("payload.medium_capabilities", p.MediumCapabilities); err != nil {
			return nil, err
		}
		if err := requireUniqueNonEmpty("payload.effect_ceiling", p.EffectCeiling); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	case opGateDisposition:
		p, err := decodePayload[GateDispositionPayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.participant_id", p.ParticipantID); err != nil {
			return nil, err
		}
		if err := requireDigest("payload.presentation_id", p.PresentationID); err != nil {
			return nil, err
		}
		if !contains(requiredGatePostures, p.Disposition) {
			return nil, errors.New("invalid gate disposition")
		}
		if err := requireDigest("payload.reason_sha256", p.ReasonSHA256); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	case opEnter:
		p, err := decodePayload[EnterPayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireDigest("payload.presentation_id", p.PresentationID); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	case opObserveCrossing:
		p, err := decodePayload[ObserveCrossingPayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.matter_id", p.MatterID); err != nil {
			return nil, err
		}
		if err := requireDigest("payload.content_sha256", p.ContentSHA256); err != nil {
			return nil, err
		}
		if p.MediaType == "" || len(p.MediaType) > 128 || len(p.Claim) > 512 {
			return nil, errors.New("invalid crossing media_type or claim length")
		}
		return json.Marshal(p)
	case opMatterDisposition:
		p, err := decodePayload[MatterDispositionPayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.matter_id", p.MatterID); err != nil {
			return nil, err
		}
		if !contains(requiredGatePostures, p.Disposition) {
			return nil, errors.New("invalid matter disposition")
		}
		if err := requireDigest("payload.reason_sha256", p.ReasonSHA256); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	case opRecordEmergence:
		p, err := decodePayload[RecordEmergencePayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.emergence_id", p.EmergenceID); err != nil {
			return nil, err
		}
		if p.Kind == "" || len(p.Kind) > 128 || len(p.ContributorIDs) == 0 || len(p.MatterIDs) == 0 {
			return nil, errors.New("emergence requires kind, contributors, and matter")
		}
		if err := requireUniqueNonEmpty("payload.contributor_ids", p.ContributorIDs); err != nil {
			return nil, err
		}
		for _, participantID := range p.ContributorIDs {
			if err := requireSafeID("payload.contributor_ids", participantID); err != nil {
				return nil, err
			}
		}
		if err := requireUniqueNonEmpty("payload.matter_ids", p.MatterIDs); err != nil {
			return nil, err
		}
		for _, matterID := range p.MatterIDs {
			if err := requireSafeID("payload.matter_ids", matterID); err != nil {
				return nil, err
			}
		}
		if err := requireDigest("payload.description_sha256", p.DescriptionSHA256); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	case opCorrect:
		p, err := decodePayload[CorrectPayload](raw)
		if err != nil {
			return nil, err
		}
		for name, value := range map[string]string{
			"target_transition_id":   p.TargetTransitionID,
			"replacement_commitment": p.ReplacementCommitment,
			"reason_sha256":          p.ReasonSHA256,
		} {
			if err := requireDigest("payload."+name, value); err != nil {
				return nil, err
			}
		}
		return json.Marshal(p)
	case opExit:
		p, err := decodePayload[ExitPayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireDigest("payload.reason_sha256", p.ReasonSHA256); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	case opClose:
		p, err := decodePayload[ClosePayload](raw)
		if err != nil {
			return nil, err
		}
		if err := requireDigest("payload.closure_basis_sha256", p.ClosureBasisSHA256); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	case opIncorporateResidue:
		p, err := decodePayload[IncorporateResiduePayload](raw)
		if err != nil {
			return nil, err
		}
		if p.Schema != residueSchema || p.Effect != residueEffect {
			return nil, errors.New("payload is not a LOCALITY addressed residue")
		}
		if err := requireDigest("payload.residue_id", p.ResidueID); err != nil {
			return nil, err
		}
		if err := requireDigest("payload.residue_sha256", p.ResidueSHA256); err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.addressed_to_locality_id", p.AddressedToLocalityID); err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.source_locality_id", p.SourceLocalityID); err != nil {
			return nil, err
		}
		if err := requireSafeID("payload.source_locus_id", p.SourceLocusID); err != nil {
			return nil, err
		}
		if err := requireDigest("payload.source_state_commitment", p.SourceStateCommitment); err != nil {
			return nil, err
		}
		if err := requireDigest("payload.closure_transition_id", p.ClosureTransitionID); err != nil {
			return nil, err
		}
		return json.Marshal(p)
	default:
		return nil, fmt.Errorf("unsupported operation %q", operation)
	}
}

func decodePayload[T any](raw json.RawMessage) (*T, error) {
	value := new(T)
	if err := decodeStrict(raw, value); err != nil {
		return nil, err
	}
	return value, nil
}

func signTransition(unsigned UnsignedTransition, privateKey ed25519.PrivateKey) (*Transition, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return nil, errors.New("invalid Ed25519 private key")
	}
	publicKey := privateKey.Public().(ed25519.PublicKey)
	unsigned.ActorPublicKey = hex.EncodeToString(publicKey)
	transition := &Transition{Unsigned: unsigned}
	signingBytes, err := transition.SigningBytes()
	if err != nil {
		return nil, err
	}
	transition.Signature = hex.EncodeToString(ed25519.Sign(privateKey, signingBytes))
	if err := transition.ValidateSyntax(); err != nil {
		return nil, err
	}
	return transition, nil
}

func operationalActorID(publicKey ed25519.PublicKey) string {
	digest := sha256.Sum256(publicKey)
	return "LOCALITY-ACTOR-" + hex.EncodeToString(digest[:20])
}

func operationalActorIDFromHex(publicKeyHex string) string {
	publicKey, err := decodeLowerHex("actor_public_key", publicKeyHex, ed25519.PublicKeySize)
	if err != nil {
		return ""
	}
	return operationalActorID(ed25519.PublicKey(publicKey))
}
