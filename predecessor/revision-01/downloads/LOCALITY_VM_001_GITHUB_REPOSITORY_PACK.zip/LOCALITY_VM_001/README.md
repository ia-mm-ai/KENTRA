# LOCALITY VM 001

`LOCALITY_VM_001` is a non-EVM Avalanche `rpcchainvm` that makes the minimum-embodiment grammar executable as deterministic consensus state. Its protocol identity is deliberately independent of the name of any chain that embodies it.

This repository is the production-intent `1.0.0` source. A commit is eligible for deployment only after the canonical GitHub qualification workflow passes on that exact commit or tag. No live chain is created or modified by this repository pack.

## Fixed identity

| Object | Value |
|---|---|
| Protocol | `LOCALITY_VM_001` |
| Binary version | `locality-vm/1.0.0` |
| Avalanche VM ID | `4qSsv1gPp2ctpYFTt4Nm9YQqSEggVzauPw3kRGmziwVqLU1PP` |
| VM ID derivation domain | `LOCALITY_VM_001` |
| Form | `LOCALITY-FORM-001` |
| Form SHA-256 | `9fbdd054bd947c8f32308871296374009cac8c27633eb47b7c5ff2b10fcff45d` |
| AvalancheGo profile | annotated tag `v1.15.0`, peeled commit `70bd6d063b7343fd2cd8217200aaf77b57f19f68`, plus mandatory `LOCALITY_SECURITY_OVERLAY_001` |
| RPCChainVM protocol | `46` |
| Go toolchain | `1.25.13` |

The deployed locality name, source commitment, genesis ID, host authority, validator identity, L1 ID, and blockchain ID are not embedded in the VM. They are created for each distinct deployment.

## Lineage boundary

KENTRA is the formation predecessor, not the successor VM’s active name. Its chain, L1, VM, validator, validation, and body commitments remain exact ancestry references in [`lineage/KENTRA_PREDECESSOR.json`](lineage/KENTRA_PREDECESSOR.json). No authority, validator credential, balance, or shared currentness transfers from it. See [LINEAGE.md](LINEAGE.md).

## What consensus enforces

- canonical JSON blocks and transitions; unknown fields and ambiguous encodings fail closed;
- Ed25519 signatures, per-actor nonces, strict global revisions, and exact prior-state commitments;
- a genesis-bound host authority for host-only operations;
- key-derived operational actor IDs for new participants;
- presentation is not admission, admission is not entry, and entry is not matter admission;
- crossing is observation, not truth or uptake;
- emergence requires every named contributor to be present and to have locally admitted every named matter item;
- correction appends an edge and preserves its predecessor;
- closure creates addressed residue without incorporating it into the addressee;
- accepted block, state, transition, receipt, and height data commit atomically;
- restart recomputes the persisted state commitment before serving.

Private state is never required on chain. Any deliberately submitted public operation, claim, commitment, or receipt is public consensus data.

## Repository qualification

Push this pack to an empty private GitHub repository. The `Qualify LOCALITY VM 001` workflow then performs repository integrity checks, Go tests, race detection, `go vet`, a native build, exact AvalancheGo tag/commit verification, and a complete disposable three-validator lifecycle with restart and rejoin.

The canonical command used by CI is:

```bash
./scripts/qualify-linux.sh
```

The workflow exports public evidence and never exports disposable validator or locality-authority private keys. See [docs/QUALIFICATION.md](docs/QUALIFICATION.md).

## Local verification and build

On Linux with Go `1.25.13`, a native C toolchain, and network access for Go modules:

```bash
./scripts/verify.sh
./build/locality-vm --version-json
./build/locality-vm --vm-id
```

Plain AvalancheGo `v1.15.0` is the pinned upstream base, not the qualified node profile. Build the required security-overlaid node from the verified tag and dependency lock with:

```bash
GO_BINARY=/absolute/path/to/go1.25.13/bin/go \
  ./scripts/build-avalanchego.sh /secure/build/avalanchego-locality-profile
```

The builder refuses a different tag object, commit, pristine module digest, resolved dependency set, or Go version. `compat/AVALANCHEGO_SECURITY_OVERLAY_001.json` is part of the release contract. An official AvalancheGo successor may replace this overlay only after a new profile is fully qualified and versioned.

macOS arm64 may build the source natively, but it is a portability lane rather than the canonical qualification environment. The Mainnet validator host must run a binary built and qualified for its own operating system and architecture.

## Materialize one deployment

First copy and edit the descriptor; it is the explicit admission point for deployment-specific identity:

```bash
cp examples/DEPLOYMENT_DESCRIPTOR.example.json /secure/path/deployment.json
mkdir -m 700 /secure/path/locality-authority
./build/locality-vm --generate-authority /secure/path/locality-authority

./build/locality-vm --materialize-genesis \
  genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_001.json \
  /secure/path/deployment.json \
  /secure/path/locality-authority/locality-authority.public.json \
  /secure/path/genesis.json

./build/locality-vm --check-genesis /secure/path/genesis.json
```

The materializer refuses a template that already hides a locality identity, source, or authority. It also refuses to overwrite output. The private authority document is mode `0600`; keep it outside Git, backups visible to third parties, logs, screenshots, and chat.

## Deployment boundary

A real Avalanche locality still requires:

1. a successful exact-commit qualification;
2. independent review and the non-automated gates in [docs/QUALIFICATION.md](docs/QUALIFICATION.md);
3. newly generated and restorable Avalanche validator TLS/BLS credentials;
4. installation of the qualified VM binary under the exact VM ID, together with the qualified AvalancheGo profile, on every validator;
5. a materialized genesis whose descriptor names the new locality and source;
6. a distinct Avalanche L1/blockchain formation;
7. post-formation health, state-equality, balance/runway, backup, and upgrade monitoring.

Do not overwrite the predecessor VM plugin, register a NodeID whose keys are not retained, or interpret a passing software test as proof that a deployment is safe by itself.

## Interfaces and operations

- [API](docs/API.md)
- [State machine](docs/STATE_MACHINE.md)
- [Operations](docs/OPERATIONS.md)
- [Deployment handoff](docs/DEPLOYMENT_HANDOFF.md)
- [Security](SECURITY.md)
- [Release manifest](RELEASE_MANIFEST.json)

Create the release tag only after the protected `main` commit has passed qualification:

```bash
git tag -s v1.0.0 -m 'LOCALITY VM 001 v1.0.0'
git push origin v1.0.0
```

The release workflow requalifies the tag and publishes the Linux amd64 binary package plus checksums and evidence.
