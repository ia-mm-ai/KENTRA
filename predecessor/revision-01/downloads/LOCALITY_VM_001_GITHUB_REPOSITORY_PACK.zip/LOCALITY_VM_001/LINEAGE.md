# Lineage boundary

`LOCALITY_VM_001` is a successor protocol derived from KENTRA’s formation work. KENTRA remains an immutable Avalanche Mainnet predecessor reference; it is not the name, authority, validator, or current locality of this VM.

The registered KENTRA validator cannot be operated by the current custodian because its original Avalanche TLS and BLS private keys are unavailable. That is an operational boundary, not a claim that the historical chain has been deleted or that its on-chain records cease to exist.

The exact predecessor identifiers are committed in [`lineage/KENTRA_PREDECESSOR.json`](lineage/KENTRA_PREDECESSOR.json) and in every valid genesis produced from this repository. A new deployment must provide all of the following independently:

- a unique genesis and locality identity;
- a deliberately committed source reference and digest;
- a newly generated, retained locality authority;
- persisted Avalanche validator TLS and BLS credentials;
- a new Avalanche chain formation using VM ID `4qSsv1gPp2ctpYFTt4Nm9YQqSEggVzauPw3kRGmziwVqLU1PP`.

No KENTRA key, balance, validator registration, authority, or currentness is inherited.
