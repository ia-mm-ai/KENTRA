package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"slices"
)

const stateSchema = "LOCALITY_RUNTIME_STATE_001"

type RuntimeState struct {
	Schema               string                         `json:"schema"`
	Revision             uint64                         `json:"revision"`
	StateCommitment      string                         `json:"state_commitment"`
	LastTransitionID     string                         `json:"last_transition_id"`
	HostLocalityID       string                         `json:"host_locality_id"`
	ProfileFormID        string                         `json:"profile_form_id"`
	ProfileFormSHA256    string                         `json:"profile_form_sha256"`
	ActiveLocusID        string                         `json:"active_locus_id"`
	ActorKeys            map[string]string              `json:"actor_keys"`
	NextNonces           map[string]uint64              `json:"next_nonces"`
	Loci                 map[string]*LocusState         `json:"loci"`
	Events               map[string]EventRecord         `json:"events"`
	Corrections          map[string][]CorrectionRecord  `json:"corrections"`
	IncorporatedResidues map[string]IncorporatedResidue `json:"incorporated_residues"`
}

type LocusState struct {
	LocusID                string                       `json:"locus_id"`
	Phase                  string                       `json:"phase"`
	BoundTransitionID      string                       `json:"bound_transition_id"`
	PurposeSHA256          string                       `json:"purpose_sha256"`
	ClosureConditionSHA256 string                       `json:"closure_condition_sha256"`
	Presentations          map[string]PresentationState `json:"presentations"`
	Gates                  map[string]GateState         `json:"gates"`
	Entries                map[string]EntryState        `json:"entries"`
	Matter                 map[string]MatterState       `json:"matter"`
	Emergence              map[string]EmergenceState    `json:"emergence"`
	Residues               map[string]ResidueState      `json:"residues"`
	CloseTransitionID      string                       `json:"close_transition_id"`
	ClosureBasisSHA256     string                       `json:"closure_basis_sha256"`
}

type PresentationState struct {
	PresentationID     string   `json:"presentation_id"`
	ParticipantID      string   `json:"participant_id"`
	LocalityReference  string   `json:"locality_reference"`
	SourceReference    string   `json:"source_reference"`
	SourceSHA256       string   `json:"source_sha256"`
	NucleusVersion     string   `json:"nucleus_version"`
	NucleusSHA256      string   `json:"nucleus_sha256"`
	FormID             string   `json:"form_id"`
	FormSHA256         string   `json:"form_sha256"`
	StateCommitment    string   `json:"state_commitment"`
	MediumCapabilities []string `json:"medium_capabilities"`
	EffectCeiling      []string `json:"effect_ceiling"`
}

type GateState struct {
	ParticipantID  string `json:"participant_id"`
	PresentationID string `json:"presentation_id"`
	Disposition    string `json:"disposition"`
	ReasonSHA256   string `json:"reason_sha256"`
	TransitionID   string `json:"transition_id"`
}

type EntryState struct {
	ParticipantID     string `json:"participant_id"`
	PresentationID    string `json:"presentation_id"`
	EntryTransitionID string `json:"entry_transition_id"`
	Status            string `json:"status"`
	EndTransitionID   string `json:"end_transition_id"`
	EndReasonSHA256   string `json:"end_reason_sha256"`
}

type MatterState struct {
	MatterID      string                   `json:"matter_id"`
	ObserverID    string                   `json:"observer_id"`
	ContentSHA256 string                   `json:"content_sha256"`
	MediaType     string                   `json:"media_type"`
	Claim         string                   `json:"claim"`
	CrossingID    string                   `json:"crossing_id"`
	Dispositions  map[string]MatterPosture `json:"dispositions"`
}

type MatterPosture struct {
	ActorID      string `json:"actor_id"`
	Disposition  string `json:"disposition"`
	ReasonSHA256 string `json:"reason_sha256"`
	TransitionID string `json:"transition_id"`
}

type EmergenceState struct {
	EmergenceID       string   `json:"emergence_id"`
	ContributorIDs    []string `json:"contributor_ids"`
	MatterIDs         []string `json:"matter_ids"`
	Kind              string   `json:"kind"`
	DescriptionSHA256 string   `json:"description_sha256"`
	TransitionID      string   `json:"transition_id"`
	Effect            string   `json:"effect"`
}

type ResidueState struct {
	ResidueID             string `json:"residue_id"`
	ResidueSHA256         string `json:"residue_sha256"`
	Schema                string `json:"schema"`
	AddressedToLocalityID string `json:"addressed_to_locality_id"`
	SourceLocalityID      string `json:"source_locality_id"`
	SourceLocusID         string `json:"source_locus_id"`
	SourceStateCommitment string `json:"source_state_commitment"`
	ClosureTransitionID   string `json:"closure_transition_id"`
	Effect                string `json:"effect"`
}

type IncorporatedResidue struct {
	ResidueID             string `json:"residue_id"`
	ResidueSHA256         string `json:"residue_sha256"`
	Schema                string `json:"schema"`
	AddressedToLocalityID string `json:"addressed_to_locality_id"`
	SourceLocalityID      string `json:"source_locality_id"`
	SourceLocusID         string `json:"source_locus_id"`
	SourceStateCommitment string `json:"source_state_commitment"`
	ClosureTransitionID   string `json:"closure_transition_id"`
	TransitionID          string `json:"transition_id"`
	Effect                string `json:"effect"`
}

type EventRecord struct {
	TransitionID string `json:"transition_id"`
	Revision     uint64 `json:"revision"`
	Operation    string `json:"operation"`
	ActorID      string `json:"actor_id"`
	LocusID      string `json:"locus_id"`
	ObservedAt   int64  `json:"observed_at"`
	Effect       string `json:"effect"`
}

type CorrectionRecord struct {
	CorrectionTransitionID string `json:"correction_transition_id"`
	TargetTransitionID     string `json:"target_transition_id"`
	ReplacementCommitment  string `json:"replacement_commitment"`
	ReasonSHA256           string `json:"reason_sha256"`
	ActorID                string `json:"actor_id"`
}

type Receipt struct {
	Schema          string   `json:"schema"`
	TransitionID    string   `json:"transition_id"`
	Revision        uint64   `json:"revision"`
	StateCommitment string   `json:"state_commitment"`
	Operation       string   `json:"operation"`
	ActorID         string   `json:"actor_id"`
	LocusID         string   `json:"locus_id"`
	Effect          string   `json:"effect"`
	NonEffects      []string `json:"non_effects"`
}

func initialRuntimeState(genesis *Genesis) (*RuntimeState, error) {
	state := &RuntimeState{
		Schema:               stateSchema,
		Revision:             0,
		LastTransitionID:     "",
		HostLocalityID:       genesis.Locality.ID,
		ProfileFormID:        genesis.Profile.FormID,
		ProfileFormSHA256:    genesis.Profile.FormSHA256,
		ActiveLocusID:        "",
		ActorKeys:            map[string]string{genesis.Locality.ID: genesis.Locality.Authority.PublicKey},
		NextNonces:           map[string]uint64{genesis.Locality.ID: 0},
		Loci:                 make(map[string]*LocusState),
		Events:               make(map[string]EventRecord),
		Corrections:          make(map[string][]CorrectionRecord),
		IncorporatedResidues: make(map[string]IncorporatedResidue),
	}
	commitment, err := state.computeCommitment()
	if err != nil {
		return nil, err
	}
	state.StateCommitment = commitment
	return state, nil
}

func (s *RuntimeState) clone() (*RuntimeState, error) {
	bytes, err := json.Marshal(s)
	if err != nil {
		return nil, err
	}
	clone := new(RuntimeState)
	if err := decodeStrict(bytes, clone); err != nil {
		return nil, err
	}
	return clone, nil
}

func (s *RuntimeState) computeCommitment() (string, error) {
	copy := *s
	copy.StateCommitment = ""
	bytes, err := json.Marshal(&copy)
	if err != nil {
		return "", err
	}
	digest := sha256.Sum256(bytes)
	return hex.EncodeToString(digest[:]), nil
}

func (s *RuntimeState) validateLoaded() error {
	if s.Schema != stateSchema {
		return fmt.Errorf("unsupported state schema %q", s.Schema)
	}
	if err := requireDigest("state_commitment", s.StateCommitment); err != nil {
		return err
	}
	computed, err := s.computeCommitment()
	if err != nil {
		return err
	}
	if computed != s.StateCommitment {
		return errors.New("persisted state commitment mismatch")
	}
	if s.ActorKeys == nil || s.NextNonces == nil || s.Loci == nil || s.Events == nil || s.Corrections == nil || s.IncorporatedResidues == nil {
		return errors.New("persisted state contains nil collections")
	}
	return nil
}

func (s *RuntimeState) apply(genesis *Genesis, transition *Transition, transitionID string) (*Receipt, error) {
	if _, exists := s.Events[transitionID]; exists {
		return nil, errors.New("transition already exists")
	}
	u := &transition.Unsigned
	if u.Revision != s.Revision+1 {
		return nil, fmt.Errorf("revision %d does not follow current revision %d", u.Revision, s.Revision)
	}
	if u.PreviousStateCommitment != s.StateCommitment {
		return nil, errors.New("previous_state_commitment does not name the current state")
	}
	knownKey, actorKnown := s.ActorKeys[u.ActorID]
	if actorKnown && knownKey != u.ActorPublicKey {
		return nil, errors.New("actor public key differs from its established local binding")
	}
	if !actorKnown && u.Operation != opPresentForm {
		return nil, errors.New("unknown actor must first present a conformant form")
	}
	if !actorKnown && u.ActorID != s.HostLocalityID && u.ActorID != operationalActorIDFromHex(u.ActorPublicKey) {
		return nil, errors.New("new participant actor_id must be derived from actor_public_key")
	}
	if u.ActorID == s.HostLocalityID && u.ActorPublicKey != genesis.Locality.Authority.PublicKey {
		return nil, errors.New("host operation is not signed by the genesis locality authority")
	}
	expectedNonce := s.NextNonces[u.ActorID]
	if u.Nonce != expectedNonce {
		return nil, fmt.Errorf("nonce %d does not match next nonce %d for %s", u.Nonce, expectedNonce, u.ActorID)
	}
	if err := s.applyOperation(genesis, transition, transitionID); err != nil {
		return nil, err
	}
	if !actorKnown {
		s.ActorKeys[u.ActorID] = u.ActorPublicKey
	}
	s.NextNonces[u.ActorID] = expectedNonce + 1
	s.Revision = u.Revision
	s.LastTransitionID = transitionID
	s.Events[transitionID] = EventRecord{
		TransitionID: transitionID,
		Revision:     u.Revision,
		Operation:    u.Operation,
		ActorID:      u.ActorID,
		LocusID:      u.LocusID,
		ObservedAt:   u.ObservedAt,
		Effect:       u.Effect,
	}
	commitment, err := s.computeCommitment()
	if err != nil {
		return nil, err
	}
	s.StateCommitment = commitment
	return &Receipt{
		Schema:          "LOCALITY_RECEIPT_001",
		TransitionID:    transitionID,
		Revision:        s.Revision,
		StateCommitment: s.StateCommitment,
		Operation:       u.Operation,
		ActorID:         u.ActorID,
		LocusID:         u.LocusID,
		Effect:          u.Effect,
		NonEffects:      receiptNonEffects(u.Operation),
	}, nil
}

func (s *RuntimeState) activeLocus(locusID string) (*LocusState, error) {
	if s.ActiveLocusID == "" {
		return nil, errors.New("no locus is active")
	}
	if locusID != s.ActiveLocusID {
		return nil, fmt.Errorf("transition addresses locus %q but active locus is %q", locusID, s.ActiveLocusID)
	}
	locus, exists := s.Loci[locusID]
	if !exists || locus.Phase != "OPEN" {
		return nil, errors.New("active locus is not open")
	}
	return locus, nil
}

func (s *RuntimeState) requireHost(actorID string) error {
	if actorID != s.HostLocalityID {
		return errors.New("operation requires the explicit locality host authority")
	}
	return nil
}

func participantPresent(locus *LocusState, actorID string) bool {
	entry, exists := locus.Entries[actorID]
	return exists && entry.Status == "PRESENT"
}

func receiptNonEffects(operation string) []string {
	common := []string{"NO_EXTERNAL_TRUTH_INFERENCE", "NO_SOURCE_OR_AUTHORITY_TRANSFER", "NO_SHARED_CURRENTNESS"}
	switch operation {
	case opPresentForm:
		return append(common, "NO_ADMISSION_BY_PRESENTATION", "NO_ENTRY_BY_PRESENTATION", "NO_FORMATION_BY_CONFORMANCE")
	case opGateDisposition:
		return append(common, "NO_ENTRY_BY_ADMISSION")
	case opEnter:
		return append(common, "NO_MATTER_ADMISSION_BY_ENTRY")
	case opObserveCrossing:
		return append(common, "NO_ADMISSION_BY_CROSSING", "MATTER_NOT_TRUTH")
	case opMatterDisposition:
		return append(common, "NO_OTHER_LOCALITY_UPTAKE")
	case opRecordEmergence:
		return append(common, "NO_AUTOMATIC_LOCAL_UPTAKE")
	case opCorrect:
		return append(common, "NO_PREDECESSOR_ERASURE")
	case opClose:
		return append(common, "NO_ERASURE_BY_CLOSURE", "NO_LOCAL_INCORPORATION_BY_CLOSURE")
	case opIncorporateResidue:
		return append(common, "NO_SOURCE_FIELD_MUTATION", "NO_OTHER_LOCALITY_UPTAKE")
	default:
		return common
	}
}

func sortedCopy(values []string) []string {
	copy := slices.Clone(values)
	slices.Sort(copy)
	return copy
}
