package main

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"strings"
	"testing"
)

type testAuthorities struct {
	host        ed25519.PrivateKey
	participant ed25519.PrivateKey
}

func deterministicKey(fill byte) ed25519.PrivateKey {
	return ed25519.NewKeyFromSeed([]byte(strings.Repeat(string([]byte{fill}), ed25519.SeedSize)))
}

func digestText(value string) string {
	digest := sha256.Sum256([]byte(value))
	return hex.EncodeToString(digest[:])
}

func testGenesis(t *testing.T) ([]byte, *Genesis, testAuthorities) {
	t.Helper()
	keys := testAuthorities{host: deterministicKey(1), participant: deterministicKey(2)}
	genesis := &Genesis{
		Format:   genesisFormat,
		Version:  genesisVersion,
		Encoding: genesisEncoding,
		Domain: GenesisDomain{
			ID:             domainID,
			GenesisID:      "LOCALITY-RUNTIME-TEST-001",
			VMClass:        "AVALANCHE_CUSTOM_RPCCHAINVM",
			ExecutionModel: "NON_EVM_SIGNED_EVENT_SOURCED",
			StateModel:     "VERSIONED_EVENT_SOURCED_CONTAINER",
			Purpose:        "Exercise the LOCALITY executable grammar.",
		},
		Lineage: GenesisLineage{
			PredecessorChainID:         predecessorChainID,
			PredecessorL1ID:            predecessorL1ID,
			PredecessorVMID:            predecessorVMID,
			PredecessorValidationID:    predecessorValidationID,
			PredecessorValidatorNodeID: predecessorValidatorNodeID,
			PredecessorGenesisID:       predecessorGenesisID,
			PredecessorBodySHA256:      predecessorBodySHA256,
			PredecessorDisposition:     "FORMATION_COMPLETE_REFERENCE_ONLY",
			Relation:                   "DERIVED_FROM",
			Effect:                     "ANCESTRY_REFERENCE_ONLY",
			AuthorityTransfer:          "NONE",
			SharedCurrentness:          "NONE",
			ContinuationBasis:          "NEW_LOCALITY_REQUIRES_NEW_VALIDATOR_AND_AUTHORITY_CUSTODY",
		},
		Locality: GenesisLocality{
			ID:              "LOCALITY-RUNTIME-TEST",
			SourceReference: "CONTINUITY",
			SourceSHA256:    digestText("test continuity source"),
			Authority: GenesisAuthority{
				Scheme:    "ED25519",
				KeyID:     "locality-host-test-001",
				PublicKey: hex.EncodeToString(keys.host.Public().(ed25519.PublicKey)),
				Scope:     "LOCALITY_HOST_OPERATIONS_ONLY",
			},
		},
		Profile: GenesisProfile{
			FormID:         formID,
			FormSHA256:     formSHA256,
			GatePostures:   append([]string(nil), requiredGatePostures...),
			EffectCeiling:  append([]string(nil), requiredEffectCeiling...),
			NonCollapse:    append([]string(nil), requiredNonCollapse...),
			PrivateState:   "NEVER_REQUIRED_ON_CHAIN",
			AdmissionRule:  "PRESENTATION_NECESSARY_NOT_SUFFICIENT",
			CorrectionRule: "APPEND_ONLY_PRESERVE_PREDECESSOR",
		},
		InitialState: GenesisInitialState{Revision: 0, PreviousStateCommitment: nil, History: "APPEND_ONLY"},
		ClaimLimits: GenesisClaimLimits{
			ExternalTruth: "NOT_INFERRED",
			Receipt:       "NOT_INFERRED",
			Acceptance:    "NOT_INFERRED",
			Consent:       "NOT_INFERRED",
			Relation:      "NOT_CREATED_BY_GENESIS",
			Crossing:      "NOT_CREATED_BY_GENESIS",
			Unknown:       "REMAINS_UNKNOWN",
		},
		Evolution: GenesisEvolution{
			StateSchemaVersion: 1,
			UnknownFields:      "REJECT",
			GenesisMutability:  "IMMUTABLE",
			UpgradePolicy:      "EXPLICIT_VERSIONED_SUCCESSOR_ONLY",
		},
	}
	genesisBytes, err := json.MarshalIndent(genesis, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	parsed, err := parseGenesis(genesisBytes)
	if err != nil {
		t.Fatalf("test genesis is invalid: %v", err)
	}
	return genesisBytes, parsed, keys
}

func testEffectCeiling() []string {
	return append([]string(nil), requiredEffectCeiling...)
}

func testMediumCapabilities() []string {
	return append([]string(nil), requiredMediumCapabilities...)
}

func makeTransition(t *testing.T, state *RuntimeState, actorID string, key ed25519.PrivateKey, operation, locusID string, payload any) *Transition {
	t.Helper()
	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		t.Fatal(err)
	}
	transition, err := signTransition(UnsignedTransition{
		Schema:                  transitionSchema,
		Operation:               operation,
		Revision:                state.Revision + 1,
		PreviousStateCommitment: state.StateCommitment,
		ActorID:                 actorID,
		Nonce:                   state.NextNonces[actorID],
		LocusID:                 locusID,
		ObservedAt:              int64(state.Revision + 1000),
		Effect:                  operationEffects[operation],
		Payload:                 payloadBytes,
	}, key)
	if err != nil {
		t.Fatalf("sign %s: %v", operation, err)
	}
	return transition
}

func transitionHexID(t *testing.T, transition *Transition) string {
	t.Helper()
	id, err := transition.ID()
	if err != nil {
		t.Fatal(err)
	}
	return hex.EncodeToString(id[:])
}

func applyToClone(state *RuntimeState, genesis *Genesis, transition *Transition) (*RuntimeState, *Receipt, error) {
	clone, err := state.clone()
	if err != nil {
		return nil, nil, err
	}
	id, err := transition.ID()
	if err != nil {
		return nil, nil, err
	}
	receipt, err := clone.apply(genesis, transition, hex.EncodeToString(id[:]))
	return clone, receipt, err
}

func mustApply(t *testing.T, state *RuntimeState, genesis *Genesis, transition *Transition) (*RuntimeState, *Receipt, string) {
	t.Helper()
	next, receipt, err := applyToClone(state, genesis, transition)
	if err != nil {
		t.Fatalf("apply %s: %v", transition.Unsigned.Operation, err)
	}
	return next, receipt, receipt.TransitionID
}
