package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
)

const (
	residueSchema   = "LOCALITY_ADDRESSED_RESIDUE_001"
	residueEffect   = "AVAILABLE_FOR_ADDRESSEE_DECISION_ONLY"
	residueIDDomain = "LOCALITY_RESIDUE_ID_001"
)

type residueEnvelope struct {
	Schema                string `json:"schema"`
	AddressedToLocalityID string `json:"addressed_to_locality_id"`
	SourceLocalityID      string `json:"source_locality_id"`
	SourceLocusID         string `json:"source_locus_id"`
	SourceStateCommitment string `json:"source_state_commitment"`
	ClosureTransitionID   string `json:"closure_transition_id"`
	Effect                string `json:"effect"`
}

func (s *RuntimeState) applyOperation(genesis *Genesis, transition *Transition, transitionID string) error {
	u := &transition.Unsigned
	switch u.Operation {
	case opBound:
		return s.applyBound(u, transitionID)
	case opPresentForm:
		return s.applyPresentForm(genesis, u, transitionID)
	case opGateDisposition:
		return s.applyGateDisposition(u, transitionID)
	case opEnter:
		return s.applyEnter(u, transitionID)
	case opObserveCrossing:
		return s.applyObserveCrossing(u, transitionID)
	case opMatterDisposition:
		return s.applyMatterDisposition(u, transitionID)
	case opRecordEmergence:
		return s.applyRecordEmergence(u, transitionID)
	case opCorrect:
		return s.applyCorrection(u, transitionID)
	case opExit:
		return s.applyExit(u, transitionID)
	case opClose:
		return s.applyClose(u, transitionID)
	case opIncorporateResidue:
		return s.applyIncorporateResidue(u, transitionID)
	default:
		return fmt.Errorf("unsupported operation %q", u.Operation)
	}
}

func (s *RuntimeState) applyBound(u *UnsignedTransition, transitionID string) error {
	if err := s.requireHost(u.ActorID); err != nil {
		return err
	}
	if s.ActiveLocusID != "" {
		return errors.New("a locus is already active")
	}
	p, err := decodePayload[BoundPayload](u.Payload)
	if err != nil {
		return err
	}
	if p.LocusID != u.LocusID {
		return errors.New("BOUND payload and transition locus IDs differ")
	}
	if _, exists := s.Loci[p.LocusID]; exists {
		return errors.New("locus ID has already been used")
	}
	s.Loci[p.LocusID] = &LocusState{
		LocusID:                p.LocusID,
		Phase:                  "OPEN",
		BoundTransitionID:      transitionID,
		PurposeSHA256:          p.PurposeSHA256,
		ClosureConditionSHA256: p.ClosureConditionSHA256,
		Presentations:          make(map[string]PresentationState),
		Gates:                  make(map[string]GateState),
		Entries:                make(map[string]EntryState),
		Matter:                 make(map[string]MatterState),
		Emergence:              make(map[string]EmergenceState),
		Residues:               make(map[string]ResidueState),
	}
	s.ActiveLocusID = p.LocusID
	return nil
}

func (s *RuntimeState) applyPresentForm(genesis *Genesis, u *UnsignedTransition, transitionID string) error {
	locus, err := s.activeLocus(u.LocusID)
	if err != nil {
		return err
	}
	if participantPresent(locus, u.ActorID) {
		return errors.New("present participant cannot replace its form while entered")
	}
	p, err := decodePayload[PresentFormPayload](u.Payload)
	if err != nil {
		return err
	}
	if p.FormID != genesis.Profile.FormID || p.FormSHA256 != genesis.Profile.FormSHA256 {
		return errors.New("form does not match the genesis-selected LOCALITY profile")
	}
	for participantID, presentation := range locus.Presentations {
		if participantID != u.ActorID && presentation.LocalityReference == p.LocalityReference {
			return errors.New("locality reference is already presented in this locus")
		}
	}
	for _, required := range requiredMediumCapabilities {
		if !contains(p.MediumCapabilities, required) {
			return fmt.Errorf("presented form lacks local-medium capability %s", required)
		}
	}
	for _, ceiling := range genesis.Profile.EffectCeiling {
		if !contains(p.EffectCeiling, ceiling) {
			return fmt.Errorf("presented form omits genesis effect ceiling %s", ceiling)
		}
	}
	locus.Presentations[u.ActorID] = PresentationState{
		PresentationID:     transitionID,
		ParticipantID:      u.ActorID,
		LocalityReference:  p.LocalityReference,
		SourceReference:    p.SourceReference,
		SourceSHA256:       p.SourceSHA256,
		NucleusVersion:     p.NucleusVersion,
		NucleusSHA256:      p.NucleusSHA256,
		FormID:             p.FormID,
		FormSHA256:         p.FormSHA256,
		StateCommitment:    p.StateCommitment,
		MediumCapabilities: sortedCopy(p.MediumCapabilities),
		EffectCeiling:      sortedCopy(p.EffectCeiling),
	}
	delete(locus.Gates, u.ActorID)
	return nil
}

func (s *RuntimeState) applyGateDisposition(u *UnsignedTransition, transitionID string) error {
	if err := s.requireHost(u.ActorID); err != nil {
		return err
	}
	locus, err := s.activeLocus(u.LocusID)
	if err != nil {
		return err
	}
	p, err := decodePayload[GateDispositionPayload](u.Payload)
	if err != nil {
		return err
	}
	presentation, exists := locus.Presentations[p.ParticipantID]
	if !exists || presentation.PresentationID != p.PresentationID {
		return errors.New("gate disposition does not address the participant's current presentation")
	}
	if participantPresent(locus, p.ParticipantID) {
		return errors.New("gate posture cannot be rewritten while participant is entered")
	}
	locus.Gates[p.ParticipantID] = GateState{
		ParticipantID:  p.ParticipantID,
		PresentationID: p.PresentationID,
		Disposition:    p.Disposition,
		ReasonSHA256:   p.ReasonSHA256,
		TransitionID:   transitionID,
	}
	return nil
}

func (s *RuntimeState) applyEnter(u *UnsignedTransition, transitionID string) error {
	locus, err := s.activeLocus(u.LocusID)
	if err != nil {
		return err
	}
	p, err := decodePayload[EnterPayload](u.Payload)
	if err != nil {
		return err
	}
	presentation, exists := locus.Presentations[u.ActorID]
	if !exists || presentation.PresentationID != p.PresentationID {
		return errors.New("entry does not address the actor's current presentation")
	}
	gate, exists := locus.Gates[u.ActorID]
	if !exists || gate.PresentationID != p.PresentationID || gate.Disposition != "ADMIT" {
		return errors.New("entry requires an explicit current ADMIT disposition")
	}
	if participantPresent(locus, u.ActorID) {
		return errors.New("actor is already entered")
	}
	locus.Entries[u.ActorID] = EntryState{
		ParticipantID:     u.ActorID,
		PresentationID:    p.PresentationID,
		EntryTransitionID: transitionID,
		Status:            "PRESENT",
	}
	return nil
}

func (s *RuntimeState) applyObserveCrossing(u *UnsignedTransition, transitionID string) error {
	locus, err := s.activeLocus(u.LocusID)
	if err != nil {
		return err
	}
	if u.ActorID != s.HostLocalityID && !participantPresent(locus, u.ActorID) {
		return errors.New("crossing observation requires host medium or entered participant")
	}
	p, err := decodePayload[ObserveCrossingPayload](u.Payload)
	if err != nil {
		return err
	}
	if _, exists := locus.Matter[p.MatterID]; exists {
		return errors.New("matter ID has already crossed this locus")
	}
	locus.Matter[p.MatterID] = MatterState{
		MatterID:      p.MatterID,
		ObserverID:    u.ActorID,
		ContentSHA256: p.ContentSHA256,
		MediaType:     p.MediaType,
		Claim:         p.Claim,
		CrossingID:    transitionID,
		Dispositions:  make(map[string]MatterPosture),
	}
	return nil
}

func (s *RuntimeState) applyMatterDisposition(u *UnsignedTransition, transitionID string) error {
	locus, err := s.activeLocus(u.LocusID)
	if err != nil {
		return err
	}
	if u.ActorID != s.HostLocalityID && !participantPresent(locus, u.ActorID) {
		return errors.New("matter disposition requires host medium or entered participant")
	}
	p, err := decodePayload[MatterDispositionPayload](u.Payload)
	if err != nil {
		return err
	}
	matter, exists := locus.Matter[p.MatterID]
	if !exists {
		return errors.New("matter has not crossed this locus")
	}
	matter.Dispositions[u.ActorID] = MatterPosture{
		ActorID:      u.ActorID,
		Disposition:  p.Disposition,
		ReasonSHA256: p.ReasonSHA256,
		TransitionID: transitionID,
	}
	locus.Matter[p.MatterID] = matter
	return nil
}

func (s *RuntimeState) applyRecordEmergence(u *UnsignedTransition, transitionID string) error {
	if err := s.requireHost(u.ActorID); err != nil {
		return err
	}
	locus, err := s.activeLocus(u.LocusID)
	if err != nil {
		return err
	}
	p, err := decodePayload[RecordEmergencePayload](u.Payload)
	if err != nil {
		return err
	}
	if _, exists := locus.Emergence[p.EmergenceID]; exists {
		return errors.New("emergence ID has already been used")
	}
	for _, contributorID := range p.ContributorIDs {
		if !participantPresent(locus, contributorID) {
			return fmt.Errorf("contributor %s is not present", contributorID)
		}
		for _, matterID := range p.MatterIDs {
			matter, exists := locus.Matter[matterID]
			if !exists {
				return fmt.Errorf("matter %s has not crossed", matterID)
			}
			posture, exists := matter.Dispositions[contributorID]
			if !exists || posture.Disposition != "ADMIT" {
				return fmt.Errorf("contributor %s has not locally admitted matter %s", contributorID, matterID)
			}
		}
	}
	locus.Emergence[p.EmergenceID] = EmergenceState{
		EmergenceID:       p.EmergenceID,
		ContributorIDs:    sortedCopy(p.ContributorIDs),
		MatterIDs:         sortedCopy(p.MatterIDs),
		Kind:              p.Kind,
		DescriptionSHA256: p.DescriptionSHA256,
		TransitionID:      transitionID,
		Effect:            "FIELD_LOCAL_RECORD_ONLY",
	}
	return nil
}

func (s *RuntimeState) applyCorrection(u *UnsignedTransition, transitionID string) error {
	p, err := decodePayload[CorrectPayload](u.Payload)
	if err != nil {
		return err
	}
	target, exists := s.Events[p.TargetTransitionID]
	if !exists {
		return errors.New("correction target does not exist")
	}
	if target.ActorID != u.ActorID {
		return errors.New("actor may only correct its own attributed transition")
	}
	s.Corrections[p.TargetTransitionID] = append(s.Corrections[p.TargetTransitionID], CorrectionRecord{
		CorrectionTransitionID: transitionID,
		TargetTransitionID:     p.TargetTransitionID,
		ReplacementCommitment:  p.ReplacementCommitment,
		ReasonSHA256:           p.ReasonSHA256,
		ActorID:                u.ActorID,
	})
	return nil
}

func (s *RuntimeState) applyExit(u *UnsignedTransition, transitionID string) error {
	locus, err := s.activeLocus(u.LocusID)
	if err != nil {
		return err
	}
	entry, exists := locus.Entries[u.ActorID]
	if !exists || entry.Status != "PRESENT" {
		return errors.New("actor is not presently entered")
	}
	p, err := decodePayload[ExitPayload](u.Payload)
	if err != nil {
		return err
	}
	entry.Status = "EXITED"
	entry.EndTransitionID = transitionID
	entry.EndReasonSHA256 = p.ReasonSHA256
	locus.Entries[u.ActorID] = entry
	return nil
}

func (s *RuntimeState) applyClose(u *UnsignedTransition, transitionID string) error {
	if err := s.requireHost(u.ActorID); err != nil {
		return err
	}
	locus, err := s.activeLocus(u.LocusID)
	if err != nil {
		return err
	}
	p, err := decodePayload[ClosePayload](u.Payload)
	if err != nil {
		return err
	}
	for participantID, entry := range locus.Entries {
		if entry.Status != "PRESENT" && entry.Status != "EXITED" {
			continue
		}
		residue, err := makeResidue(s, locus, participantID, transitionID)
		if err != nil {
			return err
		}
		locus.Residues[participantID] = residue
		if entry.Status == "PRESENT" {
			entry.Status = "CLOSED_WITH_FIELD"
			entry.EndTransitionID = transitionID
			entry.EndReasonSHA256 = p.ClosureBasisSHA256
			locus.Entries[participantID] = entry
		}
	}
	locus.Phase = "CLOSED"
	locus.CloseTransitionID = transitionID
	locus.ClosureBasisSHA256 = p.ClosureBasisSHA256
	s.ActiveLocusID = ""
	return nil
}

func makeResidue(state *RuntimeState, locus *LocusState, participantID, closureTransitionID string) (ResidueState, error) {
	presentation, exists := locus.Presentations[participantID]
	if !exists {
		return ResidueState{}, errors.New("cannot address residue without a current presentation")
	}
	envelope := residueEnvelope{
		Schema:                residueSchema,
		AddressedToLocalityID: presentation.LocalityReference,
		SourceLocalityID:      state.HostLocalityID,
		SourceLocusID:         locus.LocusID,
		SourceStateCommitment: state.StateCommitment,
		ClosureTransitionID:   closureTransitionID,
		Effect:                residueEffect,
	}
	residueSHA, residueID, err := residueCommitments(envelope)
	if err != nil {
		return ResidueState{}, err
	}
	return ResidueState{
		ResidueID:             residueID,
		ResidueSHA256:         residueSHA,
		Schema:                envelope.Schema,
		AddressedToLocalityID: envelope.AddressedToLocalityID,
		SourceLocalityID:      state.HostLocalityID,
		SourceLocusID:         locus.LocusID,
		SourceStateCommitment: state.StateCommitment,
		ClosureTransitionID:   closureTransitionID,
		Effect:                residueEffect,
	}, nil
}

func residueCommitments(envelope residueEnvelope) (string, string, error) {
	bytes, err := json.Marshal(&envelope)
	if err != nil {
		return "", "", err
	}
	residueDigest := sha256.Sum256(bytes)
	idInput := append([]byte(residueIDDomain+"\x00"), bytes...)
	idDigest := sha256.Sum256(idInput)
	return hex.EncodeToString(residueDigest[:]), hex.EncodeToString(idDigest[:]), nil
}

func (s *RuntimeState) applyIncorporateResidue(u *UnsignedTransition, transitionID string) error {
	if err := s.requireHost(u.ActorID); err != nil {
		return err
	}
	if u.LocusID != "" {
		return errors.New("residue incorporation is local and must not impersonate a live source locus")
	}
	p, err := decodePayload[IncorporateResiduePayload](u.Payload)
	if err != nil {
		return err
	}
	if p.AddressedToLocalityID != s.HostLocalityID {
		return errors.New("residue is not addressed to this locality")
	}
	envelope := residueEnvelope{
		Schema:                p.Schema,
		AddressedToLocalityID: p.AddressedToLocalityID,
		SourceLocalityID:      p.SourceLocalityID,
		SourceLocusID:         p.SourceLocusID,
		SourceStateCommitment: p.SourceStateCommitment,
		ClosureTransitionID:   p.ClosureTransitionID,
		Effect:                p.Effect,
	}
	expectedSHA, expectedID, err := residueCommitments(envelope)
	if err != nil {
		return err
	}
	if p.ResidueSHA256 != expectedSHA || p.ResidueID != expectedID {
		return errors.New("residue commitment does not match its addressed envelope")
	}
	if _, exists := s.IncorporatedResidues[p.ResidueID]; exists {
		return errors.New("residue has already been incorporated")
	}
	s.IncorporatedResidues[p.ResidueID] = IncorporatedResidue{
		ResidueID:             p.ResidueID,
		ResidueSHA256:         p.ResidueSHA256,
		Schema:                p.Schema,
		AddressedToLocalityID: p.AddressedToLocalityID,
		SourceLocalityID:      p.SourceLocalityID,
		SourceLocusID:         p.SourceLocusID,
		SourceStateCommitment: p.SourceStateCommitment,
		ClosureTransitionID:   p.ClosureTransitionID,
		TransitionID:          transitionID,
		Effect:                "LOCAL_STATE_INCORPORATION_ONLY",
	}
	return nil
}
